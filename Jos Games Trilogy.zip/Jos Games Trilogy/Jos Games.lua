-- TNS|Jos Games|TNE --

local splash = bitmap.open("/SCRIPTS/TOOLS/Jos Games/splash.png")

local function run(event)

    if splash then
        lcd.drawBitmap(splash, 0, 0)
    end

    if event == EVT_ENTER_BREAK then
        return "/SCRIPTS/TOOLS/Jos Games/Selector.lua"
    end

    return 0

end

return { run = run }