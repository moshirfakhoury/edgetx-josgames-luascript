local toolName = "TNS|Jurassic Jos L3|TNE"

local lcdW = LCD_W
local lcdH = LCD_H

---**************************************************************************************************---
-- JURASSIC JOS - GAME CODE START
---**************************************************************************************************---
----------------------------------------------------
-- JURASSIC JOS - IMAGES
----------------------------------------------------

local josS = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/josS.png")
local josG = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/josG.png")

local bkg31 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/bkg31.png")
local bkg32 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/bkg32.png")
local bkg33 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/bkg33.png")
local bkg34 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/bkg34.png")
local bkgc = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/bkgc.png")
local trex = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/trex.png") 
local trexd = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/trexd.png") 
local bullet = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/bullet.png") 

----------------------------------------------------
-- JURASSIC JOS - LEVEL 3 VARIABLES
----------------------------------------------------
local jblivesCount = 3
local gameOver = false

local gameComplete = false

local lastJosHit = 0
local josHitCooldown = 100

local trexEating = false
local trexEatingTimer = 0
local trexEatingDuration = 200

local gamePaused = false

local eggsCollected = 0
local maxEggs = 3

local jos3W = 52
local jos3H = 80

local jos3X = 300
local jos3Y = lcdH - jos3H - 25

local jos3Speed = 5

local trex3W = 290
local trex3H = 210

local trex3X = -trex3W
local trex3Y = lcdH - trex3H - 25
local trex3Speed = 3

local trex3Active = true

local trex3SpawnTimer = getTime()
local trex3SpawnDelay = 50

local trexHitboxX = 40
local trexHitboxY = 35
local trexHitboxW = 90
local trexHitboxH = 150

local trexJosHitboxX = 40
local trexJosHitboxY = 35
local trexJosHitboxW = 185
local trexJosHitboxH = 150

local bulletW = 22
local bulletH = 7

local bulletX = 0
local bulletY = 0
local bulletSpeed = 8
local bullets = {}

local trexHits = 0
local lastSH = false
----------------------------------------------------
-- JURASSIC JOS - UPDATE LEVEL 3
----------------------------------------------------

local function updateLevel3()

    local elevator = getValue(2) or 0

    -- GAME PAUSED WHILE T-REX EATS JOS
    if gamePaused then
      if getTime() - trexEatingTimer >= trexEatingDuration then
        gamePaused = false
        trexEating = false

        jos3X = 300

        trex3X = -trex3W
        trex3Active = true
      end
      return
    end

    -- FIRE BULLET USING SH SWITCH
    local shValue = getValue("sh") or 0
    local shPressed = shValue > 0

    if shPressed and not lastSH then

      local newBullet = {
        x = jos3X,
        y = jos3Y + 25
      }

      table.insert(bullets, newBullet)

    end

    lastSH = shPressed
    

    -- MOVE BULLETS
    for i = #bullets, 1, -1 do

      bullets[i].x = bullets[i].x - bulletSpeed

      -- BULLET HAS LEFT THE SCREEN
      if bullets[i].x + bulletW < 0 then
        table.remove(bullets, i)
      end

    end

    -- BULLET COLLISION WITH T-REX
    if trex3Active then
      for i = #bullets, 1, -1 do

        if bullets[i].x < trex3X + trexHitboxX + trexHitboxW and
           bullets[i].x + bulletW > trex3X + trexHitboxX and
           bullets[i].y < trex3Y + trexHitboxY + trexHitboxH and
           bullets[i].y + bulletH > trex3Y + trexHitboxY then

            table.remove(bullets, i)
            trexHits = trexHits + 1

            -- T-REX DESTROYED AFTER 6 HITS
            if trexHits >= 6 then
              trex3Active = false
              trex3SpawnTimer = getTime()
              trexHits = 0
              break
            end
        end

      end
    end

    -- MOVE JOS LEFT AND RIGHT
    if elevator > 30 then
      jos3X = jos3X - jos3Speed
    elseif elevator < -30 then
      jos3X = jos3X + jos3Speed
    end

    -- SCREEN BOUNDARIES
    if jos3X < 0 then
      jos3X = 0
    end

    if jos3X > lcdW - jos3W then
      jos3X = lcdW - jos3W
    end

    -- JOS REACHES THE NEST
    if jos3X <= 40 then
      eggsCollected = eggsCollected + 1

      if eggsCollected >= 3 then
        gameComplete = true
      else
        jos3X = 300
      end
    end

    -- MOVE T-REX FROM LEFT TO RIGHT
    if trex3Active then

      trex3X = trex3X + trex3Speed

      -- T-REX HAS LEFT THE SCREEN
      if trex3X > lcdW then
        trex3Active = false
        trex3SpawnTimer = getTime()
      end

    else

      -- WAIT BEFORE SPAWNING NEXT T-REX
      if getTime() - trex3SpawnTimer >= trex3SpawnDelay then
        trex3X = -trex3W
        trex3Active = true
      end

    end

    -- JOS COLLISION WITH T-REX
    if trex3Active and getTime() - lastJosHit >= josHitCooldown then

      if jos3X < trex3X + trexJosHitboxX + trexJosHitboxW and
        jos3X + jos3W > trex3X + trexJosHitboxX and
        jos3Y < trex3Y + trexJosHitboxY + trexJosHitboxH and
        jos3Y + jos3H > trex3Y + trexJosHitboxY then

        jblivesCount = jblivesCount - 1
        lastJosHit = getTime()

        trexEating = true
        trexEatingTimer = getTime()
        gamePaused = true

        -- CHECK LIVES
        if jblivesCount <= 0 then
          gameOver = true
        end
      end
    end    

    -- T-REX EATING ANIMATION TIMER
    if trexEating then
      if getTime() - trexEatingTimer >= trexEatingDuration then
        trexEating = false
      end
    end

end

----------------------------------------------------
-- JURASSIC JOS - DRAW LEVEL 3
----------------------------------------------------

local function drawLevel3()

    -- BACKGROUND
    if eggsCollected == 0 then
      lcd.drawBitmap(bkg31, 0, 0)

    elseif eggsCollected == 1 then
      lcd.drawBitmap(bkg32, 0, 0)

    elseif eggsCollected == 2 then
      lcd.drawBitmap(bkg33, 0, 0)

    elseif eggsCollected >= 3 then
      lcd.drawBitmap(bkg34, 0, 0)
    end

    -- JOS
    if josG then
      lcd.drawBitmap(josG, jos3X, jos3Y)
    end

    -- T-REX
    if trex3Active then
      if trexEating and trexd then
        lcd.drawBitmap(trexd, trex3X - 10, trex3Y + 73)
      elseif trex then
        lcd.drawBitmap(trex, trex3X, trex3Y)
      end
    end

    -- BULLETS
    if bullet then
      for i = 1, #bullets do
        lcd.drawBitmap(bullet, bullets[i].x, bullets[i].y)
      end
    end

    -- LIVES
    if josS then
      for i = 1, jblivesCount do
        lcd.drawBitmap(josS, 5 + ((i - 1) * 28), lcdH - 40)
      end
    end

end

----------------------------------------------------
-- JURASSIC JOS - DRAW GAME COMPLETE
----------------------------------------------------

local function drawGameComplete()

    if bkgc then
        lcd.drawBitmap(bkgc, 0, 0)
    end

end

----------------------------------------------------
-- MAIN RUN FUNCTION
----------------------------------------------------

local function run(event)

    lcd.clear()

    -- GAME OVER
    if gameOver then

        drawLevel3()

        if math.floor(getTime() / 40) % 2 == 0 then
            lcd.drawText(lcdW / 2, lcdH / 2, "GAME OVER", CENTER + DBLSIZE + RED)
        end

        if event == EVT_ENTER_BREAK then
            return "/SCRIPTS/TOOLS/Jos Games/Selector.lua"
        end

        return 0

    end

    -- GAME COMPLETE
    if gameComplete then
      drawGameComplete()

      if event == EVT_ENTER_BREAK then
        return "/SCRIPTS/TOOLS/Jos Games/Selector.lua"
      end

      return 0
    end

    -- LEVEL 3
    updateLevel3()
    drawLevel3()

    return 0

end
----------------------------------------------------
-- RETURN
----------------------------------------------------

return { run = run }