local toolName = "TNS|Jurassic Jos|TNE"

local lcdW = LCD_W
local lcdH = LCD_H

local gameState = "intro"
local storyPlayed = false
local storyTime = 0
local storyDuration = 7 * 100

---**************************************************************************************************---
-- JURASSIC JOS - GAME CODE START
---**************************************************************************************************---
----------------------------------------------------
-- JURASSIC JOS - IMAGES
----------------------------------------------------

local backgl1 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/backgl1.png")
local backgl2 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/backgl2.png")
local jos = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/jos.png")
local josl = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/josl.png")
local josC = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/josC.png")
local josS = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/josS.png")
local heli = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/heli.png")
local inheli = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/inheli.png")
local raptor = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/raptor.png")
local eggG = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/eggG.png")
local eggB = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/eggB.png")
local eggGB = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/eggGB.png")
local eggBB = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/eggBB.png")
local teraL = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/teraL.png")
local teraR = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/teraR.png")
local terab = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/terab.png")
local blood = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/blood.png")
local introp = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/introp.png")

local hs = "/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/hs.wav"
local is = "/SCRIPTS/TOOLS/Jos Games/Jurassic Jos/is.wav"

----------------------------------------------------
-- JURASSIC JOS - GENERAL VARIABLES
----------------------------------------------------
local jrlevel = 1
local jblivesCount = 3
local jbpoints = 0
local jbLevelComplete = false

local level1Points = 20
local level2Points = 40

local gameOver = false
local gameComplete = false

local level1Complete = false
local level2CompleteScreen = false

local gameoverTimer = 0
local gameoverVisible = true
local gameOverJosImage = nil

local josHitFlash = false
local josHitTimer = 0
local josHitDuration = 100  
local josFlashRate = 10    

----------------------------------------------------
-- JURASSIC JOS - LEVEL 1 INTRO VARIABLES
----------------------------------------------------
local heliX = -220
local heliY = 10
local heliW = 220
local heliH = 86

local heliTargetX = 30
local heliSpeed = 3
local heliExitSpeed = 3

local heliIntroState = "flyingIn"
local heliHoverTimer = 0
local heliHoverDuration = 2 * 100

----------------------------------------------------
-- JURASSIC JOS - JOS LANDING VARIABLES
----------------------------------------------------
local josW = 48
local josH = 80

local josCollisionW = 30
local josCollisionH = 60

local josX = heliX + 130
local josY = heliY + 40

local josLandY = lcdH - 65 - josH

local josSpeedY = 0
local josGravity = 0.25

----------------------------------------------------
-- JURASSIC JOS - MOVEMENT VARIABLES
----------------------------------------------------
local josSpeed = 5
local josLeft = 0
local josRight = lcdW - josW

----------------------------------------------------
-- JURASSIC JOS - PTERODACTYL VARIABLES
----------------------------------------------------

local teraW = 130
local teraH = 53

local teraSpawnRate = 6 * 100  
local teraSpawnTimer = 0

local teraMinSpeed = 2
local teraMaxSpeed = 4

local teraList = {}
local teraActive = false

----------------------------------------------------
-- JURASSIC JOS - LEVEL 2 PTERODACTYLS
----------------------------------------------------

local tera2W = 200
local tera2H = 79

local tera2Left = nil
local tera2Right = nil

local tera2SpawnTimer = 0
local tera2SpawnRate = 150

----------------------------------------------------
-- JURASSIC JOS - RAPTOR VARIABLES
----------------------------------------------------

local raptorW = 179
local raptorH = 110

local raptorX = -raptorW
local raptorY = josLandY + josH - raptorH + 10
local raptorSpeed = 4

local raptorActive = false
local raptorSpawnRate = 20 * 100
local raptorSpawnTimer = 0
local raptorHitJos = false

----------------------------------------------------
-- JURASSIC JOS - EGG VARIABLES
----------------------------------------------------
local eggW = 26
local eggH = 35

local eggGList = {}
local eggGSpeed = 3
local eggGCount = 0

local eggBList = {}
local eggBSpeed = 3
local eggBCount = 0

local goldenEggsCollected = 0
local goldenEggsRequired = 3
local goldenEggIcons = {}

local eggSpawnTimer = 0
local eggSpawnRate = 150
local eggSpawnCount = 0

local goldenEggSpawnTimer = 0
local goldenEggSpawnRate = math.random(1000, 2000)

local brokenEggDuration = 50
local brokenEggList = {}

----------------------------------------------------
-- JURASSIC JOS - LEVEL 2 AIMING CIRCLE
----------------------------------------------------

local aimX = 120
local aimY = 68
local aimRadius = 5

local aimSide = nil

local aimMinY = 35 --25
local aimMaxY = 111

local aimMinXLeft = 35 --25
local aimMaxXLeft = 205 --215

local aimMinXRight = 275 --265
local aimMaxXRight = 445 --455

----------------------------------------------------
-- JURASSIC JOS - LEVEL 2 SHOOTING
----------------------------------------------------

local lastSH = false

local bloodLeftUntil = 0
local bloodRightUntil = 0

local bloodDuration = 50

----------------------------------------------------
-- JURASSIC JOS - LEVEL 2 SCORE AND MISSES
----------------------------------------------------

local teraLeftKills = 0
local teraRightKills = 0

local missedShots = 0
local missesPerLife = 3

local level2Complete = false

----------------------------------------------------
-- JURASSIC JOS - UPDATE HELICOPTER INTRO
----------------------------------------------------
local function updateHeliIntro()

    if heliIntroState == "flyingIn" then

        if heliX == -220 then
          playFile(hs)
        end

        heliX = heliX + heliSpeed

        if heliX >= heliTargetX then
            heliX = heliTargetX
            heliIntroState = "hovering"
            heliHoverTimer = getTime()
        end

    elseif heliIntroState == "hovering" then

        if getTime() - heliHoverTimer >= heliHoverDuration then
            josX = heliX + 130
            josY = heliY + 40
            josSpeedY = 0
            heliIntroState = "josJump"
        end

    elseif heliIntroState == "josJump" then

        josSpeedY = josSpeedY + josGravity
        josY = josY + josSpeedY

        if josY >= josLandY then
          josY = josLandY
          josSpeedY = 0
          heliIntroState = "heliLeaving"
        end

    elseif heliIntroState == "heliLeaving" then

       heliY = heliY - heliExitSpeed
         if heliY + heliH < 0 then
           heliIntroState = "finished"
           teraSpawnTimer = getTime()
           teraActive = true

           raptorSpawnTimer = getTime()
           raptorActive = false
         end
    end


end
----------------------------------------------------
-- JURASSIC JOS - DRAW HELICOPTER INTRO
----------------------------------------------------
local function drawHeliIntro()

    lcd.clear()

    if backgl1 then
        lcd.drawBitmap(backgl1, 0, 0)
    end

    if teraL then
      for i = 1, #teraList do
        local tera = teraList[i]
        lcd.drawBitmap(teraL, tera.x, tera.y)
      end
    end

    -- DRAW EGGS
    for i = 1, #eggBList do
        local egg = eggBList[i]

        if egg.broken then
            if eggBB then
                lcd.drawBitmap(eggBB, egg.x, egg.y)
            end
        else
            if eggB then
                lcd.drawBitmap(eggB, egg.x, egg.y)
            end
        end
    end

    for i = 1, #eggGList do
        local egg = eggGList[i]

        if egg.broken then
            if eggGB then
                lcd.drawBitmap(eggGB, egg.x, egg.y)
            end
        else
            if eggG then
                lcd.drawBitmap(eggG, egg.x, egg.y)
            end
        end
    end

    if raptorActive and raptor then
      lcd.drawBitmap(raptor, raptorX, raptorY)
    end

    if heli and heliIntroState ~= "finished" then
      lcd.drawBitmap(heli, heliX, heliY)
    end

    
    -- DRAW JOS WITH CORRECT IMAGE AND HIT FLASH
    if heliIntroState == "josJump"
    or heliIntroState == "heliLeaving"
    or heliIntroState == "finished" then

        local throttle = getValue(3)
        local crouching = getValue("sh") > 100
        local josImage

        if gameOver and gameOverJosImage then
          josImage = gameOverJosImage
        elseif crouching and josC then
          josImage = josC
        elseif throttle >= 0 then
          josImage = jos
        else
          josImage = josl
        end

        -- UPDATE FLASH TIMER
        local showJos = true

        if josHitFlash then
            local elapsed = getTime() - josHitTimer

            if elapsed >= josHitDuration then
                josHitFlash = false
            else
                showJos = math.floor(elapsed / josFlashRate) % 2 == 0
            end
        end

        -- DRAW JOS
        if showJos and josImage then
            if crouching then
                lcd.drawBitmap(josImage, josX, josY + 40)
            else
                lcd.drawBitmap(josImage, josX, josY)
            end
        end
    end

    -- DRAW LIVES - BOTTOM LEFT
    if josS then
      for i = 1, jblivesCount do
        lcd.drawBitmap(josS, 5 + ((i - 1) * 28), lcdH - 40)
      end
    end

    -- DRAW COLLECTED GOLDEN EGGS - BOTTOM RIGHT
    for i = 1, #goldenEggIcons do
        if eggG then
            lcd.drawBitmap(eggG, lcdW - 5 - (i * (eggW + 5)) + 5, lcdH - eggH - 5)
        end
    end

end

----------------------------------------------------
-- JURASSIC JOS - UPDATE JOS
----------------------------------------------------
local function updateJos()

    local elevator = getValue(2)
    local throttle = getValue(3)
    local crouching = getValue("sh") > 100

    if not elevator then
        elevator = 0
    end

    if not throttle then
        throttle = 0
    end

    if crouching then
      return
    end

    -- JOS FACING RIGHT
    if throttle >= 0 then

        if elevator > 30 then
            josX = josX + josSpeed
        elseif elevator < -30 then
            josX = josX - josSpeed
        end

    -- JOS FACING LEFT
    else

        if elevator > 30 then
            josX = josX - josSpeed
        elseif elevator < -30 then
            josX = josX + josSpeed
        end

    end

    -- SCREEN BOUNDARIES
    if josX < josLeft then
        josX = josLeft
    end

    if josX > josRight then
        josX = josRight
    end

end

----------------------------------------------------
-- JURASSIC JOS - UPDATE PTERODACTYL
----------------------------------------------------
local function updateTera()

    if not teraActive then
        return
    end

    -- INITIALISE GOLDEN EGG TIMER
    if goldenEggSpawnTimer == 0 then
        goldenEggSpawnTimer = getTime() + goldenEggSpawnRate
    end

    -- SPAWN TIMER
    if getTime() - teraSpawnTimer >= teraSpawnRate then
        teraSpawnTimer = getTime()

        local speed = math.random(teraMinSpeed, teraMaxSpeed)

        table.insert(teraList, {
            x = lcdW,
            y = math.random(5, 60),
            speed = speed,
            eggDropTimer = getTime() + math.random(300, 700)
        })
    end

    -- MOVE PTERODACTYLS, DROP EGGS AND REMOVE OFFSCREEN ONES
    for i = #teraList, 1, -1 do
        local tera = teraList[i]

        tera.x = tera.x - tera.speed

        -- SPAWN GOLDEN EGGS AT RANDOM INTERVALS
        if goldenEggsCollected < goldenEggsRequired
        and getTime() >= goldenEggSpawnTimer then

            table.insert(eggGList, {
                x = tera.x + teraW / 2,
                y = tera.y + teraH,
                speed = eggGSpeed,
                broken = false
            })

            goldenEggSpawnRate = math.random(1000, 2000)
            goldenEggSpawnTimer = getTime() + goldenEggSpawnRate
        end

        -- DROP GREEN EGG
        if getTime() >= tera.eggDropTimer then

            table.insert(eggBList, {
                x = tera.x + teraW / 2,
                y = tera.y + teraH,
                speed = eggBSpeed,
                broken = false
            })

            eggBCount = eggBCount + 1
            eggSpawnCount = eggSpawnCount + 1

            -- NEXT DROP TIME
            tera.eggDropTimer = getTime() + math.random(300, 700)
        end

        -- REMOVE PTERODACTYL WHEN OFFSCREEN
        if tera.x + teraW < 0 then
            table.remove(teraList, i)
        end
    end
end

----------------------------------------------------
-- JURASSIC JOS - UPDATE EGGS
----------------------------------------------------
local function updateEggs()

    local eggGroundY = lcdH - 60
    local brokenGroundY = lcdH - 50

    -- UPDATE GREEN EGGS
    for i = #eggBList, 1, -1 do
        local egg = eggBList[i]

        if egg.broken then
            if getTime() - egg.brokenTimer >= brokenEggDuration then
                table.remove(eggBList, i)
            end
        else
            egg.y = egg.y + egg.speed

            -- CHECK COLLISION WITH JOS
            local crouching = getValue("sh") > 100

            if not crouching and not egg.hitJos then
                if egg.x < josX + (josW - josCollisionW) / 2 + josCollisionW
                and egg.x + eggW > josX + (josW - josCollisionW) / 2
                and egg.y < josY + (josH - josCollisionH) / 2 + josCollisionH
                and egg.y + eggH > josY + (josH - josCollisionH) / 2 then

                    jblivesCount = jblivesCount - 1
                    egg.hitJos = true

                    -- START JOS FLASH
                    josHitFlash = true
                    josHitTimer = getTime()

                    -- GAME OVER WHEN ALL LIVES ARE LOST
                    if jblivesCount <= 0 then
                        jblivesCount = 0

                        if getValue("sh") > 100 then
                            gameOverJosImage = josC
                        elseif getValue(3) >= 0 then
                            gameOverJosImage = jos
                        else
                            gameOverJosImage = josl
                        end

                        gameOver = true
                    end
                end
            end

            -- CHECK GROUND COLLISION
            if egg.y + eggH >= eggGroundY then
                egg.y = brokenGroundY - eggH
                egg.broken = true
                egg.brokenTimer = getTime()
            end
        end
    end

    -- UPDATE GOLDEN EGGS
    for i = #eggGList, 1, -1 do
        local egg = eggGList[i]

        if egg.broken then
            if getTime() - egg.brokenTimer >= brokenEggDuration then
                table.remove(eggGList, i)
            end
        else
            egg.y = egg.y + egg.speed

            -- CHECK COLLECTION WITH JOS
            local crouching = getValue("sh") > 100

            if not crouching then
                if egg.x < josX + (josW - josCollisionW) / 2 + josCollisionW
                and egg.x + eggW > josX + (josW - josCollisionW) / 2
                and egg.y < josY + (josH - josCollisionH) / 2 + josCollisionH
                and egg.y + eggH > josY + (josH - josCollisionH) / 2 then

                    goldenEggsCollected = goldenEggsCollected + 1
                    table.insert(goldenEggIcons, goldenEggsCollected)
                    table.remove(eggGList, i)
       
                    -- LEVEL 1 COMPLETE
                    if jrlevel == 1 and goldenEggsCollected >= goldenEggsRequired then
                        level1Complete = true
                    end

                end
            end

            -- CHECK GROUND COLLISION
            if eggGList[i] == egg and egg.y + eggH >= eggGroundY then
                egg.y = brokenGroundY - eggH
                egg.broken = true
                egg.brokenTimer = getTime()
            end
        end
    end

end
----------------------------------------------------
-- JURASSIC JOS - UPDATE RAPTOR
----------------------------------------------------
local function updateRaptor()

    if heliIntroState ~= "finished" then
      return
    end

    -- SPAWN RAPTOR
    if not raptorActive then
        if getTime() - raptorSpawnTimer >= raptorSpawnRate then
            raptorSpawnTimer = getTime()
            raptorX = -raptorW
            raptorY = josLandY + josH - raptorH
            raptorHitJos = false
            raptorActive = true
        end
    end

    -- MOVE RAPTOR FROM LEFT TO RIGHT
    if raptorActive then
        raptorX = raptorX + raptorSpeed
        
        -- CHECK COLLISION WITH JOS
        local crouching = getValue("sh") > 100

        if not crouching and not raptorHitJos then
            if raptorX < josX + josW
            and raptorX + raptorW > josX
            and raptorY < josY + josH
            and raptorY + raptorH > josY then

              jblivesCount = jblivesCount - 1
              raptorHitJos = true

              -- START JOS FLASH
              josHitFlash = true
              josHitTimer = getTime()

              -- GAME OVER WHEN ALL LIVES ARE LOST
              if jblivesCount <= 0 then
                jblivesCount = 0

                if getValue("sh") > 100 then
                  gameOverJosImage = josC
                elseif getValue(3) >= 0 then
                  gameOverJosImage = jos
                else
                  gameOverJosImage = josl
                end
                gameOver = true
              end

            end
        end

        -- REMOVE RAPTOR WHEN IT LEAVES THE SCREEN
        if raptorX > lcdW then
            raptorActive = false
        end
    end
end

----------------------------------------------------
-- JURASSIC JOS - DRAW LEVEL COMPLETE
----------------------------------------------------

local function drawLevelComplete()

    lcd.drawText(lcdW / 2,lcdH / 2 - 25,"LEVEL " .. jrlevel .. " COMPLETE",CENTER + DBLSIZE + YELLOW)
    lcd.drawText(lcdW / 2,lcdH / 2 + 5,"PRESS ENTER",CENTER + MIDSIZE + WHITE)

end

----------------------------------------------------
-- JURASSIC JOS - UPDATE LEVEL 2 PTERODACTYLS
----------------------------------------------------

local function updateTera2()

    -- RANDOM SPAWN TIMER
    if getTime() - tera2SpawnTimer >= tera2SpawnRate then

        tera2SpawnTimer = getTime()

        -- FIND AN EMPTY SIDE
        local emptySides = {}

        if not tera2Left and getTime() >= bloodLeftUntil then
            table.insert(emptySides, "left")
        end

        if not tera2Right and getTime() >= bloodRightUntil then
            table.insert(emptySides, "right")
        end

        -- SPAWN ON A RANDOM EMPTY SIDE
        if #emptySides > 0 then

            local side = emptySides[math.random(1, #emptySides)]

            local tera = {
                scale = 20,
                scaleTimer = getTime()
            }

            if side == "left" then
                tera2Left = tera
            else
                tera2Right = tera
            end

        end

        -- NEXT RANDOM SPAWN
        tera2SpawnRate = math.random(100, 300)

    end

    -- GROW LEFT PTERODACTYL
    if tera2Left then

        if tera2Left.scale < 100
        and getTime() - tera2Left.scaleTimer >= 100 then

            tera2Left.scale = math.min(tera2Left.scale + 20, 100)
            tera2Left.scaleTimer = getTime()

        end

    end

    -- GROW RIGHT PTERODACTYL
    if tera2Right then

        if tera2Right.scale < 100
        and getTime() - tera2Right.scaleTimer >= 100 then

            tera2Right.scale = math.min(tera2Right.scale + 20, 100)
            tera2Right.scaleTimer = getTime()

        end

    end

end


----------------------------------------------------
-- JURASSIC JOS - DRAW LEVEL 2 PTERODACTYLS
----------------------------------------------------

local function drawTera2(tera, side)

    if not tera or not terab then
        return
    end

    -- CALCULATE CURRENT IMAGE SIZE
    local drawW = tera2W * tera.scale / 100
    local drawH = tera2H * tera.scale / 100

    -- POSITION ON LEFT OR RIGHT
    local x

    if side == "left" then
        x = 25
    else
        x = lcdW - 25 - drawW
    end

    -- WINDSCREEN HEIGHT POSITION
    local y = 80

    if side == "right" then
        y = y - 20
    end

    -- DRAW SCALED PTERODACTYL
    lcd.drawBitmap(terab, x, y, tera.scale)

end

----------------------------------------------------
-- JURASSIC JOS - UPDATE AIMING CIRCLE
----------------------------------------------------

local function updateAim()

    local ch1 = getValue("ch1") or 0
    local ch2 = getValue("ch2") or 0
    local ch4 = getValue("ch4") or 0

    -- SELECT SIDE
    if ch4 <= -50 then
        aimSide = "left"
    elseif ch4 >= 50 then
        aimSide = "right"
    else
        aimSide = nil
    end

    -- HIDE CIRCLE WHEN CH4 IS CENTRED
    if not aimSide then
        return
    end

    -- HORIZONTAL MOVEMENT
    if aimSide == "left" then

        aimX = 120 + (ch1 / 1024) * 95
        aimX = math.max(aimMinXLeft,math.min(aimMaxXLeft, aimX))

    else

        aimX = 360 + (ch1 / 1024) * 95
        aimX = math.max(aimMinXRight,math.min(aimMaxXRight, aimX))

    end
    -- VERTICAL MOVEMENT
    aimY = 68 + (ch2 / 1024) * 43
    aimY = math.max(aimMinY,math.min(aimMaxY, aimY))

end

----------------------------------------------------
-- JURASSIC JOS - DRAW AIMING CIRCLE
----------------------------------------------------

local function drawAim()

    if not aimSide then
        return
    end

    lcd.drawFilledCircle(aimX,aimY,aimRadius,RED)

end

----------------------------------------------------
-- JURASSIC JOS - DRAW BLOOD SPLAT
----------------------------------------------------

local function drawBlood(side)

    if not blood then
        return
    end

    local x

    if side == "left" then
        x = 100
    else
        x = lcdW - 155
    end

    local y = 60

    lcd.drawBitmap(blood, x, y)

end

----------------------------------------------------
-- JURASSIC JOS - SHOOTING AND HIT DETECTION
----------------------------------------------------

local function updateShooting()

    local shValue = getValue("sh") or 0
    local shPressed = shValue > 0

    -- FIRE ONCE PER SWITCH ACTIVATION
    if shPressed and not lastSH then

        if aimSide then

            local tera = nil

            if aimSide == "left" then
                tera = tera2Left
            else
                tera = tera2Right
            end

            local hit = false

            -- CHECK FOR A HIT
            if tera then

                local drawW = tera2W * tera.scale / 100
                local drawH = tera2H * tera.scale / 100

                local teraX
                local teraY = 80

                if aimSide == "left" then
                    teraX = 25
                else
                    teraX = lcdW - 25 - drawW
                    teraY = teraY - 20
                end

                -- STRICT HIT DETECTION
                if aimX >= teraX
                and aimX <= teraX + drawW
                and aimY >= teraY
                and aimY <= teraY + drawH then

                    hit = true

                    -- REMOVE PTERODACTYL AND COUNT KILL
                    if aimSide == "left" then
                        teraLeftKills = teraLeftKills + 1
                        tera2Left = nil
                        bloodLeftUntil = getTime() + bloodDuration
                    else
                        teraRightKills = teraRightKills + 1
                        tera2Right = nil
                        bloodRightUntil = getTime() + bloodDuration
                    end

                    -- CHECK LEVEL 2 COMPLETION
                    if teraLeftKills >= 10 and teraRightKills >= 10 then
                        level2Complete = true
                        level2CompleteScreen = true   
                        jrlevel = 2
                    end

                end

            end

            -- COUNT MISSED SHOTS
            if not hit then

                missedShots = missedShots + 1

                if missedShots >= missesPerLife then

                    jblivesCount = jblivesCount - 1
                    missedShots = 0

                    if jblivesCount <= 0 then
                        jblivesCount = 0
                        gameOver = true
                    end

                end

            end

        else

            -- NO SIDE SELECTED: SHOT COUNTS AS A MISS
            missedShots = missedShots + 1

            if missedShots >= missesPerLife then

                jblivesCount = jblivesCount - 1
                missedShots = 0

                if jblivesCount <= 0 then
                    jblivesCount = 0
                    gameOver = true
                end

            end

        end

    end

    lastSH = shPressed

end

----------------------------------------------------
-- JURASSIC JOS - DRAW LEVEL 2
----------------------------------------------------

local function drawLevel2()

    if inheli then
        lcd.drawBitmap(inheli, 0, 0)
    end


    if josS then
        for i = 1, jblivesCount do
            lcd.drawBitmap(josS, 5 + ((i - 1) * 28), lcdH - 40)
        end
    end

    drawTera2(tera2Left, "left")
    drawTera2(tera2Right, "right")

end

----------------------------------------------------
-- JURASSIC JOS - DRAW STORY INTRO
----------------------------------------------------

local function drawStoryIntro()

    if introp then
        lcd.drawBitmap(introp, 0, 0)
    end

end

----------------------------------------------------
-- MAIN RUN FUNCTION
----------------------------------------------------

local function run(event)

    lcd.clear()

    -- STORY INTRO
    if gameState == "intro" then

        if not storyPlayed then
            storyPlayed = true
            storyTime = getTime()
            playFile(is)
        end

        drawStoryIntro()

        if getTime() - storyTime >= storyDuration then
            gameState = "level1"
        end

        return 0

    end

    -- LEVEL 1 COMPLETE
    if level1Complete then

        drawHeliIntro()
        drawLevelComplete()

        if event == EVT_ENTER_BREAK then
            level1Complete = false
            jrlevel = 2
            gameState = "level2"
        end

        return 0

    end

    -- GAME OVER
    if gameOver then

        drawHeliIntro()

        if math.floor(getTime() / 40) % 2 == 0 then
            lcd.drawText(lcdW / 2, lcdH / 2, "GAME OVER", CENTER + DBLSIZE + RED)
        end

        if event == EVT_ENTER_BREAK then
            return "/SCRIPTS/TOOLS/Jos Games/Selector.lua"
        end

        return 0

    end

    -- LEVEL 2 COMPLETE SCREEN
    if level2CompleteScreen then

      drawLevel2()
      drawLevelComplete()

      if event == EVT_ENTER_BREAK then
        return "/SCRIPTS/TOOLS/Jos Games/JurassicJosL3.lua"
      end

      return 0

    end

    -- LEVEL 2
    if gameState == "level2" then

        updateTera2()
        updateAim()
        updateShooting()

        drawLevel2()
        drawAim()

        -- DRAW BLOOD EFFECTS
        if getTime() < bloodLeftUntil then
            drawBlood("left")
        end

        if getTime() < bloodRightUntil then
            drawBlood("right")
        end

        return 0

    end

    -- NORMAL GAME
    updateHeliIntro()
    updateTera()
    updateEggs()
    updateRaptor()

    if heliIntroState == "finished" then
        updateJos()
    end

    drawHeliIntro()

    return 0

end

----------------------------------------------------
-- RETURN
----------------------------------------------------

return { run = run }
