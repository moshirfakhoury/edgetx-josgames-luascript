-- TNS|Jos Games Selector|TNE -- 

local lcdW = LCD_W
local lcdH = LCD_H

----------------------------------------------------
-- GAME IMAGES
----------------------------------------------------

local JurassicJos = bitmap.open("/SCRIPTS/TOOLS/Jos Games/JurassicJos.png")
local JosBusters = bitmap.open("/SCRIPTS/TOOLS/Jos Games/JosBusters.png")
local JosJaws = bitmap.open("/SCRIPTS/TOOLS/Jos Games/JosJaws.png")
local choosegame = bitmap.open("/SCRIPTS/TOOLS/Jos Games/ChooseGame.png")

----------------------------------------------------
-- GAME SELECTION
----------------------------------------------------

local selectedGame = 1

local gameSelectX = {10, 193, 377}
local gameSelectY = 55

local gameSelectW = 93
local gameSelectH = 200

----------------------------------------------------
-- DRAW SELECTOR
----------------------------------------------------

local function drawSelector()

    lcd.clear()

    lcd.drawFilledRectangle(0, 0, lcdW, lcdH, BLACK)

    if choosegame then
        lcd.drawBitmap(choosegame,(lcdW - 300) / 2,5)
    end

    if JurassicJos then
        lcd.drawBitmap(JurassicJos,gameSelectX[1],gameSelectY)
    end

    if JosBusters then
        lcd.drawBitmap(JosBusters,gameSelectX[2],gameSelectY)
    end

    if JosJaws then
        lcd.drawBitmap(JosJaws,gameSelectX[3],gameSelectY)
    end

    ------------------------------------------------
    -- SELECTION BOX
    ------------------------------------------------

    lcd.drawRectangle(gameSelectX[selectedGame] - 3,gameSelectY - 3,gameSelectW + 6,gameSelectH + 6,YELLOW)

end

----------------------------------------------------
-- UPDATE SELECTOR
----------------------------------------------------

local function updateSelector(event)

    ------------------------------------------------
    -- SCROLLER RIGHT
    ------------------------------------------------

    if event == EVT_ROT_RIGHT then

        selectedGame = selectedGame + 1

        if selectedGame > 3 then
            selectedGame = 1
        end

    end

    ------------------------------------------------
    -- SCROLLER LEFT
    ------------------------------------------------

    if event == EVT_ROT_LEFT then

        selectedGame = selectedGame - 1

        if selectedGame < 1 then
            selectedGame = 3
        end

    end

    ------------------------------------------------
    -- ENTER
    ------------------------------------------------

    if event == EVT_ENTER_BREAK then

        if selectedGame == 1 then

            return "/SCRIPTS/TOOLS/Jos Games/JurassicJos.lua"

        elseif selectedGame == 2 then

            return "/SCRIPTS/TOOLS/Jos Games/JosBusters.lua"

        elseif selectedGame == 3 then

            return "/SCRIPTS/TOOLS/Jos Games/JosJaws.lua"

        end

    end

    return nil

end

----------------------------------------------------
-- MAIN
----------------------------------------------------

local function run(event)

    local nextScript = updateSelector(event)

    if nextScript then
        return nextScript
    end

    drawSelector()

    return 0

end

return { run = run }
