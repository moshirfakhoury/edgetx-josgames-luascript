local toolName = "TNS|Jos Busters|TNE"

local lcdW = LCD_W
local lcdH = LCD_H

local gameState = "busters"
local storyPlayed = false
local storyTime = 0
local storyDuration = 9 * 100

---**************************************************************************************************---
-- JOS BUSTERS - GAME CODE START
---**************************************************************************************************---
----------------------------------------------------
-- JOS BUSTERS - IMAGES
----------------------------------------------------
local gstbl = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/ghostBL.png")
local gstbr = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/ghostBR.png")
local gstgl = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/ghostGL.png")
local gstgr = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/ghostGR.png")
local gstpl = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/ghostPL.png")
local gstpr = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/ghostPR.png")
local gstwl = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/ghostWL.png")
local gstwr = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/ghostWR.png")
local gstf = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/fghost.png")
local gcld = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/gcld.png")

local jbjosl = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/josL.png")
local jbjosr = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/josR.png")
local jbjosGW = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/josGhostW.png")
local millie = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/millie.png")

local laserL = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/laserL.png")
local laserR = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/laserR.png")
local nova = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/nova.png")

local jbbackground1 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/jbbackG1.png")
local jbbackground2 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/jbbackG2.png")
local jbbackground3 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/jbbackG3.png")
local jbbackpic1 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Busters/jbbackp1.png")

local jbsnd = "/SCRIPTS/TOOLS/Jos Games/Jos Busters/jbsd.wav"
local gs1 = "/SCRIPTS/TOOLS/Jos Games/Jos Busters/gs1.wav"
local gs2 = "/SCRIPTS/TOOLS/Jos Games/Jos Busters/gs2.wav"

----------------------------------------------------
-- JOS BUSTERS - GENERAL VARIABLES
----------------------------------------------------
local jblevel = 1
local jblivesCount = 3
local jbpoints = 0
local jbLevelComplete = false

local level1Points = 20
local level2Points = 40

local gameOver = false
local gameComplete = false

local jbJosGhost = false
local jbJosGhostTimer = 0
local jbJosGhostDuration = 1.5 * 30
local jbJosGhostFlashTimer = 0

local gameoverTimer = 0
local gameoverVisible = true
local millieLost = false

----------------------------------------------------
-- LEVEL 3 VARIABLES
----------------------------------------------------

-- FGhost
local fghostX = 350
local fghostY = 50
local fghostW = 116
local fghostH = 170

-- FGhost health
local fghostHits = 0
local fghostMaxHits = 40
local fghostDefeated = false
local fghostFlashTimer = 0

-- Collision widths
local fghostCollisionW = 90
local millieCollisionW = 35

-- Millie health
local millieHits = 0
local millieMaxHits = 3
local millieSaved = true

-- FGhost movement
local fghostYDirection = 1
local fghostSpeed = 1.5

-- Special ammunition
local specialAmmo = 65

-- Special projectile (Nova)
local novaActive = false
local novaX = 0
local novaY = 0
local novaSpeed = 3

-- Ghost cloud
local cloudActive = false
local cloudX = 0
local cloudY = 0
local cloudSpeed = 3
local cloudW = 66
local cloudH = 50

-- Cloud timing
local cloudNextTime = 0
local cloudMinDelay = 8
local cloudMaxDelay = 30

local novaW = 38
local novaH = 25

----------------------------------------------------
-- JOS BUSTERS - TOP BAR
----------------------------------------------------

local function drawJBTopBar()


    lcd.drawFilledRectangle(0, 0, lcdW, 30, GREY)

    lcd.drawText(5, 5, "Lives: " .. jblivesCount, WHITE)
    lcd.drawText(75, 5, "Ghost Count: " .. jbpoints, YELLOW)

    if jblevel == 3 then
      lcd.drawText(215, 5, "MILLIE: " .. millieHits .. "/3", WHITE)
      lcd.drawText(325,5,"NOVA: " .. specialAmmo, YELLOW)
    end

    lcd.drawText(lcdW - 5, 5, "Level: " .. jblevel, RIGHT + WHITE)

end
----------------------------------------------------
-- JOS BUSTERS - JOS MOVEMENT
----------------------------------------------------

local jbjosSpeed = 4

local jbjosX = 100
local jbjosY = lcdH - 135 - 10

local jbjosLeft = 0
local jbjosRight = lcdW - 75

----------------------------------------------------
-- JOS BUSTERS - LASER
----------------------------------------------------

local jbLaserX = 0
local jbLaserY = 0

----------------------------------------------------
-- JOS BUSTERS - UPDATE LASER
----------------------------------------------------

local function updateJBLaser()

    -- JOS IS A GHOST - LASER OFF
    if jbJosGhost then
        jbLaserX = nil
        jbLaserY = nil
        return
    end

    local throttle = getValue(3)

    -- LASER OFF
    if getValue("SH") < -700 then
        jbLaserX = nil
        jbLaserY = nil
        return
    end

    -- JOS FACING RIGHT
    if throttle >= 0 then
        jbLaserX = jbjosX + 75
        jbLaserY = 167

    -- JOS FACING LEFT
    else
        jbLaserX = jbjosX - 103
        jbLaserY = 167

    end

end

----------------------------------------------------
-- JOS BUSTERS - DRAW LASER
----------------------------------------------------

local function drawJBLaser()

    if jbLaserX == nil or jbLaserY == nil then
        return
    end

    local throttle = getValue(3)
    local laserImage

    -- JOS FACING RIGHT
    if throttle >= 0 then
        laserImage = laserR

    -- JOS FACING LEFT
    else
        laserImage = laserL
    end

    if laserImage then
        lcd.drawBitmap(laserImage, jbLaserX, jbLaserY)
    end

end

----------------------------------------------------
-- JOS BUSTERS - GHOSTS
----------------------------------------------------

local ghosts = {}

local maxGhosts = 8

local ghostSpeed = 3

local ghostSpawnTimer = 0
local ghostSpawnRate = 50

local ghostW = 80
local ghostH = 86

----------------------------------------------------
-- JOS BUSTERS - LASER / GHOST COLLISION
----------------------------------------------------

local function checkLaserGhostCollision()

    if jbLaserX == nil or jbLaserY == nil then
        return
    end

    local throttle = getValue(3)
    local collisionX
    local collisionW

    -- JOS FACING RIGHT
    if throttle >= 0 then

        collisionX = jbLaserX
        collisionW = 110

    -- JOS FACING LEFT
    else
        collisionX = jbLaserX
        collisionW = 110
    end

    for i = #ghosts, 1, -1 do

        local ghost = ghosts[i]

        if not ghost.hit then

            if collisionX < ghost.x + ghost.w and
               collisionX + collisionW > ghost.x and
               jbLaserY < ghost.y + ghost.h and
               jbLaserY + 1 > ghost.y then

                ghost.hit = true
                ghost.flashTimer = 0
                ghost.flashCount = 0

                jbpoints = jbpoints + 1
                -- CHECK LEVELS
                if jblevel == 1 and jbpoints >= level1Points then
                  jbLevelComplete = true
                elseif jblevel == 2 and jbpoints >= level2Points then
                  jbLevelComplete = true
                end 
            end

        end

    end

end

----------------------------------------------------
-- JOS BUSTERS - UPDATE HIT GHOSTS
----------------------------------------------------

local function updateHitGhosts()

    for i = #ghosts, 1, -1 do

        local ghost = ghosts[i]

        if ghost.hit then

            ghost.flashTimer = ghost.flashTimer + 1

            -- FLASH EVERY 5 FRAMES
            if ghost.flashTimer >= 5 then
                ghost.flashTimer = 0
                ghost.flashCount = ghost.flashCount + 1
            end

            -- REMOVE AFTER A COUPLE OF FLASHES
            if ghost.flashCount >= 4 then
                table.remove(ghosts, i)
            end

        end

    end

end
----------------------------------------------------
-- JOS BUSTERS - SPAWN GHOST
----------------------------------------------------

local function spawnGhost()

    if #ghosts >= maxGhosts then
        return
    end

    local ghost = {}

    ------------------------------------------------
    -- RANDOMLY CHOOSE LEFT OR RIGHT GHOST
    ------------------------------------------------

    if math.random(1, 2) == 1 then

        -- L GHOST - FLYS RIGHT TO LEFT
        local ghostType = math.random(1, 4)

        if ghostType == 1 then
            ghost.image = gstbl
        elseif ghostType == 2 then
            ghost.image = gstgl
        elseif ghostType == 3 then
            ghost.image = gstpl
        else
            ghost.image = gstwl
        end

        ghost.direction = -1
        ghost.x = lcdW + ghostW

    else

        -- R GHOST - FLYS LEFT TO RIGHT
        local ghostType = math.random(1, 4)

        if ghostType == 1 then
            ghost.image = gstbr
        elseif ghostType == 2 then
            ghost.image = gstgr
        elseif ghostType == 3 then
            ghost.image = gstpr
        else
            ghost.image = gstwr
        end

        ghost.direction = 1
        ghost.x = -ghostW

    end

    -- RANDOM VERTICAL POSITION
    ghost.y = math.random(90, lcdH - ghostH - 25)

    ghost.w = ghostW
    ghost.h = ghostH

    ghost.speed = ghostSpeed

    ghost.hit = false
    ghost.flashTimer = 0
    ghost.flashCount = 0

    table.insert(ghosts, ghost)
    if jbpoints < 20 then
      playFile(gs1)
    end

end

----------------------------------------------------
-- JOS BUSTERS - UPDATE GHOSTS
----------------------------------------------------
local function updateGhosts()

    if jblevel == 3 and fghostDefeated then
        ghosts = {}
        return
    end

    for i = #ghosts, 1, -1 do

        local ghost = ghosts[i]

        ghost.x = ghost.x + (ghost.speed * ghost.direction)

        -- REMOVE LEFT-FLYING GHOST WHEN OFF LEFT
        if ghost.direction == -1 then

            if ghost.x + ghost.w < 0 then
                table.remove(ghosts, i)
            end

        -- REMOVE RIGHT-FLYING GHOST WHEN OFF RIGHT
        else

            if ghost.x > lcdW then
                table.remove(ghosts, i)
            end

        end

    end

end

----------------------------------------------------
-- JOS BUSTERS - GHOST / JOS COLLISION
----------------------------------------------------
local function checkGhostJosCollision()

    if jbJosGhost then
        return
    end

    for i = #ghosts, 1, -1 do

        local ghost = ghosts[i]

        if not ghost.hit then

            -- GHOST / JOS COLLISION
            if jbjosX < ghost.x + ghost.w and
               jbjosX + 78 > ghost.x and
               jbjosY < ghost.y + ghost.h and
               jbjosY + 135 > ghost.y then

                -- LOSE ONE LIFE
                jblivesCount = jblivesCount - 1

                -- CHECK FOR GAME OVER
                if jblivesCount <= 0 then
                  gameOver = true
                end

                -- START GHOST TRANSFORMATION
                jbJosGhost = true
                jbJosGhostTimer = 0
                jbJosGhostFlashTimer = 0

                -- REMOVE THE GHOST THAT HIT JOS
                table.remove(ghosts, i)

                break
            end
        end

    end

end

----------------------------------------------------
-- LEVEL 3 - NOVA / FHOST COLLISION
----------------------------------------------------
local function checkNovaFGhostCollision()

    if jblevel ~= 3 then
        return
    end

    if not novaActive then
        return
    end

    -- Is FGhost currently visible?
    local fghostVisible =
        not fghostDefeated and
        math.floor(fghostFlashTimer / 40) % 2 == 0

    -- NOVA HITS FHOST WHILE VISIBLE
    if fghostVisible and
       novaX < fghostX + fghostCollisionW and
       novaX + novaW > fghostX and
       novaY < fghostY + fghostH and
       novaY + novaH > fghostY then

        fghostHits = fghostHits + 1
        novaActive = false

        if fghostHits >= fghostMaxHits then

            fghostDefeated = true

            if millieSaved then
                gameComplete = true
            else
                gameOver = true
            end

        end

        return
    end

    -- NOVA HITS MILLIE WHILE FHOST IS INVISIBLE
    if not fghostVisible and
       novaX < millieX + millieCollisionW and
       novaX + novaW > millieX and
       novaY < millieY + 160 and
       novaY + novaH > millieY then

        if millieHits < millieMaxHits then
          millieHits = millieHits + 1
        end
        novaActive = false

        if millieHits >= millieMaxHits then
            millieSaved = false
            millieLost = true
        end

    end

end

----------------------------------------------------
-- LEVEL 3 - NOVA / GHOST CLOUD COLLISION
----------------------------------------------------
local function checkNovaCloudCollision()

    if jblevel ~= 3 then
        return
    end

    if not novaActive then
        return
    end

    if not cloudActive then
        return
    end

    if novaX < cloudX + cloudW and
       novaX + novaW > cloudX and
       novaY < cloudY + cloudH and
       novaY + novaH > cloudY then

        novaActive = false
        cloudActive = false

        cloudNextTime = getTime() +
            math.random(cloudMinDelay * 100, cloudMaxDelay * 100)

    end

end

----------------------------------------------------
-- LEVEL 3 - GHOST CLOUD / JOS COLLISION
----------------------------------------------------

local function checkCloudJosCollision()

    if jblevel ~= 3 then
        return
    end

    if not cloudActive then
        return
    end

    if jbJosGhost then
        return
    end

    if cloudX < jbjosX + 78 and
       cloudX + cloudW > jbjosX and
       cloudY < jbjosY + 135 and
       cloudY + cloudH > jbjosY then

        cloudActive = false
        jblivesCount = 0
        gameOver = true

    end

end
----------------------------------------------------
-- JOS BUSTERS - UPDATE JOS GHOST TRANSFORMATION
----------------------------------------------------

local function updateJBJosGhost()

    if not jbJosGhost then
        return
    end

    jbJosGhostTimer = jbJosGhostTimer + 1
    jbJosGhostFlashTimer = jbJosGhostFlashTimer + 1

    if jbJosGhostTimer >= jbJosGhostDuration then
        jbJosGhost = false
        jbJosGhostTimer = 0
        jbJosGhostFlashTimer = 0
    end

end
----------------------------------------------------
-- JOS BUSTERS - DRAW GHOSTS
----------------------------------------------------
local function drawGhosts()

    for i = 1, #ghosts do

        local ghost = ghosts[i]

        -- NORMAL GHOST
        if not ghost.hit then
            lcd.drawBitmap(ghost.image, ghost.x, ghost.y)

        -- HIT GHOST - FLASH
        else
            if math.floor(ghost.flashTimer / 2) % 2 == 0 then
                lcd.drawBitmap(ghost.image, ghost.x, ghost.y)
            end
        end

    end

end
----------------------------------------------------
-- JOS BUSTERS - UPDATE GHOST SPAWN
----------------------------------------------------
local function updateGhostSpawn()

    if jblevel == 3 and fghostDefeated then
      return
    end

    ghostSpawnTimer = ghostSpawnTimer + 1

    if ghostSpawnTimer >= ghostSpawnRate then

        spawnGhost()

        ghostSpawnTimer = 0

    end

end
----------------------------------------------------
-- JOS BUSTERS - UPDATE JOS
----------------------------------------------------
local function updateJBJos()

    local elevator = getValue(2)
    local throttle = getValue(3)

    if not elevator then
        elevator = 0
    end

    if not throttle then
        throttle = 0
    end

    -- JOS FACING RIGHT
    if throttle >= 0 then

        if elevator > 30 then
            jbjosX = jbjosX + jbjosSpeed
        elseif elevator < -30 then
            jbjosX = jbjosX - jbjosSpeed
        end

    -- JOS FACING LEFT
    else

        if elevator > 30 then
            jbjosX = jbjosX - jbjosSpeed
        elseif elevator < -30 then
            jbjosX = jbjosX + jbjosSpeed
        end

    end

    -- SCREEN BOUNDARIES
    if jbjosX < jbjosLeft then
        jbjosX = jbjosLeft
    end

    if jbjosX > jbjosRight then
        jbjosX = jbjosRight
    end

end

----------------------------------------------------
-- LEVEL 3 - FGHOST + MILLIE MOVEMENT
----------------------------------------------------

local function updateFGhost()

    if jblevel ~= 3 then
        return
    end

    fghostY = fghostY + (fghostSpeed * fghostYDirection)

    -- Keep FGhost on screen
    if fghostY <= 30 then
        fghostY = 30
        fghostYDirection = 1

    elseif fghostY + fghostH >= lcdH then
        fghostY = lcdH - fghostH
        fghostYDirection = -1
    end

    -- Keep Millie attached to FGhost
    if not fghostDefeated then
        millieX = fghostX + 35
        millieY = fghostY + 10
    else
        -- FGhost defeated - Millie moves to bottom
        millieX = fghostX + 35
        millieY = lcdH - 160
    end

end

----------------------------------------------------
-- LEVEL 3 - FIRE NOVA
----------------------------------------------------
local function fireNova()

    if jblevel ~= 3 then
        return
    end

    if specialAmmo <= 0 then
        return
    end

    if novaActive then
        return
    end

    local throttle = getValue(3) 

    if throttle >= 0 and getValue("ch1") >= 30 then

        novaActive = true
        novaX = jbjosX + 78
        novaY = jbjosY + 35

        specialAmmo = specialAmmo - 1

    end

end

----------------------------------------------------
-- LEVEL 3 - UPDATE NOVA
----------------------------------------------------
local function updateNova()

    if not novaActive then
        return
    end

    novaX = novaX + novaSpeed

    -- Remove Nova when it leaves the screen
    if novaX > lcdW then
        novaActive = false
    end

end

----------------------------------------------------
-- LEVEL 3 - FGHOST FLASH
----------------------------------------------------

local function updateFGhostFlash()

    if jblevel ~= 3 then
        return
    end

    if fghostDefeated then
        return
    end

    fghostFlashTimer = fghostFlashTimer + 1

end

----------------------------------------------------
-- LEVEL 3 - SPAWN GHOST CLOUD
----------------------------------------------------

local function updateGhostCloud()

    if jblevel ~= 3 then
        return
    end

    if fghostDefeated then
        return
    end

    if cloudActive then
        return
    end

    if getTime() >= cloudNextTime then

        cloudActive = true
        cloudX = fghostX
        cloudY = lcdH - 115
        playFile(gs2)
    end
    
    

end

----------------------------------------------------
-- LEVEL 3 - UPDATE GHOST CLOUD
----------------------------------------------------

local function updateGhostCloudMovement()

    if not cloudActive then
        return
    end

    cloudX = cloudX - cloudSpeed

    if cloudX < -100 then
        cloudActive = false

        cloudNextTime = getTime() +
            math.random(cloudMinDelay * 100, cloudMaxDelay * 100)
    end

end
----------------------------------------------------
-- JOS BUSTERS - DRAW JOS
----------------------------------------------------

local function drawJBJos()


    -- JOS IS TURNING INTO A GHOST
    if jbJosGhost then
        if math.floor(jbJosGhostFlashTimer / 5) % 2 == 0 then

            if jbjosGW then
                lcd.drawBitmap(jbjosGW, jbjosX, jbjosY)
            end
        end

        return
    end

    -- NORMAL JOS
    local throttle = getValue(3)
    local josImage

    if throttle >= 0 then
        josImage = jbjosr
    else
        josImage = jbjosl
    end

    if josImage then
        lcd.drawBitmap(josImage, jbjosX, jbjosY)
    end

end

----------------------------------------------------
-- JOS BUSTERS - DRAW GAME OVER
----------------------------------------------------
local function drawGameOver()

    if not gameoverVisible then
        return
    end

    if millieLost then

        lcd.drawText(lcdW / 2,lcdH / 2 - 25,"GAME OVER",CENTER + DBLSIZE + RED)
        lcd.drawText(lcdW / 2,lcdH / 2 + 10,"YOU KILLED THE GHOSTS",CENTER + MIDSIZE + WHITE)
        lcd.drawText(lcdW / 2,lcdH / 2 + 30,"BUT DID NOT SAVE MILLIE",CENTER + MIDSIZE + WHITE)
        lcd.drawText(lcdW / 2,lcdH / 2 + 50,"PRESS ENTER",CENTER + MIDSIZE + WHITE)

    else

        lcd.drawText(lcdW / 2,lcdH / 2 - 20,"GAME OVER",CENTER + DBLSIZE + RED)
        lcd.drawText(lcdW / 2,lcdH / 2 + 10,"PRESS ENTER",CENTER + MIDSIZE + WHITE)

    end

end

----------------------------------------------------
-- JOS BUSTERS - GAME OVER FLASH
----------------------------------------------------

local function gameoverFlash()

    if not gameOver then
        return
    end

    gameoverTimer = gameoverTimer + 1

    if gameoverTimer % 20 < 10 then
        gameoverVisible = true
    else
        gameoverVisible = false
    end

end

----------------------------------------------------
-- JOS BUSTERS - DRAW LEVEL COMPLETE
----------------------------------------------------

local function drawLevelComplete()

    lcd.drawText(lcdW / 2,lcdH / 2 - 25,"LEVEL " .. jblevel .. " COMPLETE",CENTER + DBLSIZE + YELLOW)
    lcd.drawText(lcdW / 2,lcdH / 2 + 5,"PRESS ENTER",CENTER + MIDSIZE + WHITE)

end
----------------------------------------------------
-- JOS BUSTERS - DRAW BACKGROUND
----------------------------------------------------

local function drawJBBackground()

    if jblevel == 1 then
        lcd.drawBitmap(jbbackground1, 0, 0)

    elseif jblevel == 2 then
        lcd.drawBitmap(jbbackground2, 0, 0)
    else
        lcd.drawBitmap(jbbackground3, 0, 0)
    end

end

----------------------------------------------------
-- JOS BUSTERS - STORY SCREEN
----------------------------------------------------

local function drawStory()

    lcd.drawBitmap(jbbackpic1,0,0)

end

----------------------------------------------------
-- LEVEL 3 - DRAW FGHOST + MILLIE
----------------------------------------------------
local function drawFGhost()

    if jblevel ~= 3 then
        return
    end

    if millieSaved then
        lcd.drawBitmap(millie, millieX, millieY)
    end

    -- Draw FGhost while he is alive and flashing
    if not fghostDefeated then
        if math.floor(fghostFlashTimer / 40) % 2 == 0 then
            lcd.drawBitmap(gstf, fghostX, fghostY)
        end
    end

end

----------------------------------------------------
-- LEVEL 3 - DRAW NOVA
----------------------------------------------------

local function drawNova()

    if not novaActive then
        return
    end

    lcd.drawBitmap(nova,novaX,novaY)

end

----------------------------------------------------
-- JOS BUSTERS - DRAW GAME COMPLETE
----------------------------------------------------

local function drawGameComplete()

    lcd.drawText(lcdW / 2,lcdH / 2 - 25,"GAME COMPLETE",CENTER + DBLSIZE + GREEN)
    lcd.drawText(lcdW / 2,lcdH / 2 + 10,"YOU HAVE SAVED MILLIE",CENTER + MIDSIZE + WHITE)

end
----------------------------------------------------
-- LEVEL 3 - DRAW GHOST CLOUD
----------------------------------------------------

local function drawGhostCloud()

    if not cloudActive then
        return
    end

    lcd.drawBitmap(gcld, cloudX, cloudY)

end

---**************************************************************************************************---
-- JOS BUSTERS - GAME CODE END
---**************************************************************************************************---

----------------------------------------------------
-- MAIN LOOP
----------------------------------------------------

local function run(event)

    lcd.clear()

----------------------------------------------------
-- STORY SCREEN
----------------------------------------------------

if gameState == "story" then

    drawStory()

    -- START STORY TIMER
    if storyTime == 0 then
        storyTime = getTime()
    end

    -- PLAY STORY SOUND ONCE
    if not storyPlayed then
        playFile(jbsnd)
        storyPlayed = true
    end

    -- AUTOMATICALLY MOVE TO LEVEL 3 AFTER 9 SECONDS
    if getTime() - storyTime >= storyDuration then
        gameState = "busters"
        jblevel = 3

        ghostSpawnRate = 30
        ghostSpeed = 3
        specialAmmo = 65
        fghostHits = 0

        cloudActive = false
        cloudNextTime = getTime() + math.random(cloudMinDelay * 100, cloudMaxDelay * 100)

        storyTime = 0
        storyPlayed = false

        ghosts = {}
    end

    return 0

end

if gameState == "busters" then

    -- GAME OVER
    if gameOver then

        drawJBBackground()
        drawJBTopBar()
        drawGhosts()
        drawJBJos()
        drawJBLaser()

        drawGameOver()
        gameoverFlash()

        if event == EVT_ENTER_BREAK then
            return "/SCRIPTS/TOOLS/Jos Games/Selector.lua"
        end

        return 0

    end

    -- GAME COMPLETE
    if gameComplete then

        drawJBBackground()
        drawJBTopBar()
        drawJBJos()
        drawFGhost()
        drawGameComplete()

        if event == EVT_ENTER_BREAK then
            return "/SCRIPTS/TOOLS/Jos Games/Selector.lua"
        end

        return 0

    end

    -- LEVEL COMPLETE
    if jbLevelComplete then

      drawJBBackground()
      drawJBTopBar()
      drawGhosts()
      drawJBJos()
      drawLevelComplete()

      if event == EVT_ENTER_BREAK then

        if jblevel == 1 then
          jblevel = 2
          maxGhosts = 10
          ghostSpawnRate = 30
          ghostSpeed = 5

        elseif jblevel == 2 then
          gameState = "story"
          storyPlayed = false
          storyTime = 0
        end

        jbLevelComplete = false
        ghosts = {}

    end
 
    return 0

    end

    -- NORMAL GAME
    updateJBJos()
    --updateJBJosGhost()
    updateJBLaser()
    fireNova()
    updateNova()
    checkNovaFGhostCollision()
    checkNovaCloudCollision()
    checkCloudJosCollision()

    updateGhostSpawn()
    updateGhosts()
    updateFGhost()
    updateFGhostFlash()
    updateGhostCloud()
    updateGhostCloudMovement()

    checkGhostJosCollision()
    checkLaserGhostCollision()
    updateHitGhosts()
    updateJBJosGhost()

    drawJBBackground()
    drawJBTopBar()
    drawGhosts()
    drawJBJos()
    drawJBLaser()
    drawNova()
    drawFGhost()
    drawGhostCloud()

    gameoverFlash()

    return 0

end

end

----------------------------------------------------
-- RETURN
----------------------------------------------------

return { run = run }
