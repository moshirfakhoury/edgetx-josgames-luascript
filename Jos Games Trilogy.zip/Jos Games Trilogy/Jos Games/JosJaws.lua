local toolName = "TNS|Jos Jaws|TNE"

local lcdW = LCD_W
local lcdH = LCD_H

----------------------------------------------------
-- JOS JAWS - LOAD SCORE MODULE
----------------------------------------------------

local scoreChunk, scoreError = loadScript("/SCRIPTS/TOOLS/Jos Games/JJScores.lua")

if not scoreChunk then
    error("Could not load JJScores.lua: " .. tostring(scoreError))
end

local JJScores = scoreChunk()

JJScores.start()

local leaderboardActive = true
local scoreSubmitted = false

---**************************************************************************************************---
-- JOS JAWS - GAME CODE START
---**************************************************************************************************---

local gameState = "jawsIntro"

----------------------------------------------------
-- JOS JAWS - IMAGES
----------------------------------------------------
local clownf = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/ClownF.png")
local fish2 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/Fish2.png")
local fish3 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/Fish3.png")
local jellyf = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/JellyF.png")
local jjbackground1 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/JJbackG1.png")
local jjbackground2 = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/JJbackG2.png")
local JosJJ = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/JosJJ.png")
local key = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/key.png")
local sharkwl = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/SharkWL.png")
local sharkwr = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/SharkWR.png")
local chest = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/chest.png")
local scuba = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/scuba.png")
local josjawsintro = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/jjintro.png")
local josjawsintroSound = "/SCRIPTS/TOOLS/Jos Games/Jos Jaws/jjints.wav"
----------------------------------------------------
-- JOS JAWS - GENERAL VARIABLES
----------------------------------------------------
local level = 1

local livesCount = 3

local keyFound = false
local gameOver = false

local jawsIntroTime = 0
local jawsIntroDuration = 12 * 100   
local jawsIntroPlayed = false

----------------------------------------------------
-- JOS JAWS - JOS
----------------------------------------------------

local josX = 100
local josY = 120

local josW = 75
local josH = 47

local josCollisionW = 30
local josCollisionH = 16

local josTop = 32
local josBottom = lcdH - josH - 5

local josLeft = 5
local josRight = lcdW - josW - 5

----------------------------------------------------
-- JOS JAWS - AIR / SCUBA
----------------------------------------------------

local airTime = 90
local maxAirTime = 90

local scubaW = 43
local scubaH = 30

local scubaX = -scubaW
local scubaY = 100

local scubaVisible = false
local scubaSpeed = 2

local scubaTriggered = false

----------------------------------------------------
-- JOS JAWS - AIR TIMER
----------------------------------------------------

local function updateAir()

    airTime = airTime - (1 / 30)

    if airTime <= 0 then

        airTime = 0
        gameOver = true

    end

end

----------------------------------------------------
-- JOS JAWS - AIR BAR
----------------------------------------------------

local function drawAirBar()

    local barX = 230
    local barY = 8
    local barW = 150
    local barH = 8

    local airColor

    if airTime > 40 then
        airColor = GREEN
    elseif airTime > 20 then
        airColor = YELLOW
    else
        airColor = RED
    end


    lcd.drawFilledRectangle(barX,barY,barW,barH,DARKGREY)

    local airWidth = math.floor((airTime / maxAirTime) * barW)

    if airWidth > 0 then
        lcd.drawFilledRectangle(barX,barY,airWidth,barH,airColor)
    end

    lcd.drawText(barX - 27,barY - 6,"AIR",WHITE)

end

----------------------------------------------------
-- JOS JAWS - UPDATE SCUBA
----------------------------------------------------

local function updateScuba()

    if airTime <= 25 and not scubaTriggered then
        scubaTriggered = true
        scubaVisible = true

        scubaX = lcdW
        scubaY = math.random(35,lcdH - scubaH - 5)
    end

    if scubaVisible then
        scubaX = scubaX - scubaSpeed

        if scubaX + scubaW < 0 then
            scubaVisible = false
        end
    end

end

----------------------------------------------------
-- JOS JAWS - CHECK SCUBA COLLISION
----------------------------------------------------

local function checkScubaCollision()

    if not scubaVisible then
        return
    end

    if scubaX < josX + josW and
       scubaX + scubaW > josX and
       scubaY < josY + josH and
       scubaY + scubaH > josY then

        airTime = maxAirTime
        scubaVisible = false
        scubaTriggered = false
    end

end

----------------------------------------------------
-- DRAW SCUBA
----------------------------------------------------

local function drawScuba()

    if not scubaVisible then
        return
    end

    lcd.drawBitmap(scuba,scubaX,scubaY)

end

----------------------------------------------------
-- JOS JAWS - JELLYFISH
----------------------------------------------------

local jellyfish = {}

local jellyTimer = 0

-- Starting spawn rate
local jellySpawnRate = 65

-- Maximum jellyfish on screen
local maxJellyfish = 6

local jellyW = 10
local jellyH = 30

----------------------------------------------------
-- JOS JAWS - CLOWNFISH
----------------------------------------------------

local clownfish = {}

local clownTimer = 0

local clownSpawnRate = 45

local clownW = 38
local clownH = 25

----------------------------------------------------
-- JOS JAWS - OTHER FISH
----------------------------------------------------

local otherFish = {}

local otherFishTimer = 0

local otherFishSpawnRate = 55

local fishW = 38
local fishH = 25

----------------------------------------------------
-- JOS JAWS - KEY
----------------------------------------------------

local keyX = 380
local keyY = 120

local keyW = 32
local keyH = 32

-- Key timing
local keyVisible = false
local keyTimer = 0

-- Key is visible for 1 second
local keyVisibleTime = 15

-- Key stays hidden for 1.5 seconds
local keyHiddenTime = 120

-- Count missed key appearances
local keyMisses = 0

-- Start with the key hidden
local keyWaiting = true

-- Small floating movement
local keyFloat = 0

----------------------------------------------------
-- JOS JAWS - HIT / INVULNERABILITY
----------------------------------------------------

local hitTimer = 0

-- Jos cannot lose another life while this is active
local hitDuration = 45

----------------------------------------------------
-- JOS JAWS - LEVEL COMPLETE
----------------------------------------------------

local levelCompleteTimer = 0

----------------------------------------------------
-- GAMEOVER FLASH
----------------------------------------------------

local gameoverTimer = 0
local gameoverVisible = true

----------------------------------------------------
-- JOS JAWS - LEVEL 2 - GENERAL VARIABLES
----------------------------------------------------

local level2Started = false

----------------------------------------------------
-- JOS JAWS - LEVEL 2 - TREASURE CHEST
----------------------------------------------------

local chestX = 0
local chestY = 0

local chestW = 35
local chestH = 30

local chestVisible = false
local chestTimer = 0
local chestRespawnTimer = 0
local chestRespawnDelay = 30
local firstChestDelay = 90
local firstChestTimer = 0

local chestVisibleTime = keyVisibleTime
local chestsCollected = 0

----------------------------------------------------
-- JOS JAWS - LEVEL 2 - SHARKS
----------------------------------------------------
local shark = nil
local sharkTimer = 0
local sharkSpawnDelay = 90

local sharkWLW = 100
local sharkWLH = 51

local sharkWRW = 150
local sharkWRH = 71

local sharkSpeed = 4

----------------------------------------------------
-- JOS JAWS - LEVEL 2 - SHARK COLLISION
----------------------------------------------------

local sharkHit = false

----------------------------------------------------
-- DRAW BACKGROUND
----------------------------------------------------

local function drawBackground()

    if level == 1 then
        lcd.drawBitmap(jjbackground1, 0, 0)

    elseif level == 2 then
        lcd.drawBitmap(jjbackground2, 0, 0)

    end

end

----------------------------------------------------
-- JOS JAWS - DRAW TOP BAR
----------------------------------------------------

local function drawTopBar()

    lcd.drawFilledRectangle(0, 0, lcdW, 30, BLACK)
    lcd.drawText(10, 5, "LIVES: "..livesCount, WHITE)

    if level == 2 and keyFound then
        lcd.drawBitmap(key, 100, 6)
    end

    if level == 2 then
      lcd.drawBitmap(chest, 145, 0)
      lcd.drawText(183,5,tostring(chestsCollected),WHITE)
    end

    lcd.drawText(lcdW - 80, 5, "LEVEL "..level, WHITE)

end
----------------------------------------------------
-- JOS JAWS - UPDATE JOS
----------------------------------------------------

local function updateJos()

    if hitTimer > 0 then
        hitTimer = hitTimer - 1
    end

    local stickY = getValue(3)
    local stickX = getValue(2)

    if not stickY then
        stickY = 0
    end

    if not stickX then
        stickX = 0
    end

    ------------------------------------------------
    -- VERTICAL
    ------------------------------------------------

    local normY = (stickY + 1024) / 2048

    josY = josTop +
           ((josBottom - josTop) * (1 - normY))

    ------------------------------------------------
    -- HORIZONTAL
    ------------------------------------------------

    local normX = (stickX + 1024) / 2048

    josX = josLeft +
           ((josRight - josLeft) * (1 - normX))

end


----------------------------------------------------
-- JOS JAWS - DRAW JOS
----------------------------------------------------

local function drawJos()

    -- Blink after being hit

    if hitTimer > 0 then

        if hitTimer % 6 < 3 then
            return
        end

    end

    if JosJJ then
        lcd.drawBitmap(JosJJ, josX, josY)
    end

end

----------------------------------------------------
-- JOS JAWS - CREATE JELLYFISH
----------------------------------------------------

local function spawnJellyfish()

    -- Don't create more than the current maximum
    if #jellyfish >= maxJellyfish then
        return
    end

    local jelly = {}

    jelly.x = math.random(5, lcdW - jellyW - 5)

    -- Start below the screen
    jelly.y = lcdH + 5

    jelly.w = jellyW
    jelly.h = jellyH

    -- Random speed
    jelly.speed = math.random(2, 4)

    table.insert(jellyfish, jelly)

end

----------------------------------------------------
-- JOS JAWS - UPDATE JELLYFISH
----------------------------------------------------

local function updateJellyfish()

    jellyTimer = jellyTimer + 1

    ------------------------------------------------
    -- SPAWN
    ------------------------------------------------

    if jellyTimer >= jellySpawnRate then

        spawnJellyfish()

        jellyTimer = 0

    end


    ------------------------------------------------
    -- MOVE
    ------------------------------------------------

    for i = #jellyfish, 1, -1 do

        local j = jellyfish[i]

        j.y = j.y - j.speed

        ------------------------------------------------
        -- REMOVE WHEN OFF SCREEN
        ------------------------------------------------

        if j.y + j.h < 30 then

            table.remove(jellyfish, i)

        end

    end

end

----------------------------------------------------
-- JOS JAWS - DRAW JELLYFISH
----------------------------------------------------

local function drawJellyfish()

    for i = 1, #jellyfish do

        local j = jellyfish[i]

        lcd.drawBitmap(jellyf, j.x, j.y)

    end

end

----------------------------------------------------
-- JOS JAWS - CREATE CLOWNFISH
----------------------------------------------------

local function spawnClownfish()

    local clown = {}

    -- Enter from the LEFT
    clown.x = -clownW - 5

    clown.y = math.random(40, lcdH - clownH - 5)

    clown.w = clownW
    clown.h = clownH

    clown.speed = math.random(2, 4)

    table.insert(clownfish, clown)

end

----------------------------------------------------
-- JOS JAWS - UPDATE CLOWNFISH
----------------------------------------------------

local function updateClownfish()

    clownTimer = clownTimer + 1

    if clownTimer >= clownSpawnRate then

        spawnClownfish()

        clownTimer = 0

    end

    for i = #clownfish, 1, -1 do

        local c = clownfish[i]

        -- Move LEFT To RIGHT
        c.x = c.x + c.speed

        -- Remove when off the RIGHT side
        if c.x > lcdW then

            table.remove(clownfish, i)

        end

    end

end

----------------------------------------------------
-- JOS JAWS - DRAW CLOWNFISH
----------------------------------------------------

local function drawClownfish()

    for i = 1, #clownfish do

        local c = clownfish[i]

        lcd.drawBitmap(clownf, c.x, c.y)

    end

end

----------------------------------------------------
-- JOS JAWS - CREATE OTHER FISH
----------------------------------------------------

local function spawnOtherFish()

    local fish = {}

    -- Enter from the RIGHT
    fish.x = lcdW + 5

    -- Random vertical position
    fish.y = math.random(
        40,
        lcdH - fishH - 5
    )

    fish.w = fishW
    fish.h = fishH

    fish.speed = math.random(2, 4)

    -- Randomly choose Fish2 or Fish3
    if math.random(1, 2) == 1 then
        fish.image = fish2
    else
        fish.image = fish3
    end

    table.insert(otherFish, fish)

end

----------------------------------------------------
-- JOS JAWS - UPDATE OTHER FISH
----------------------------------------------------

local function updateOtherFish()

    otherFishTimer = otherFishTimer + 1

    ------------------------------------------------
    -- SPAWN
    ------------------------------------------------

    if otherFishTimer >= otherFishSpawnRate then

        spawnOtherFish()

        otherFishTimer = 0

    end


    ------------------------------------------------
    -- MOVE RIGHT → LEFT
    ------------------------------------------------

    for i = #otherFish, 1, -1 do

        local fish = otherFish[i]

        fish.x = fish.x - fish.speed

        ------------------------------------------------
        -- REMOVE WHEN OFF LEFT SIDE
        ------------------------------------------------

        if fish.x + fish.w < 0 then

            table.remove(otherFish, i)

        end

    end

end

----------------------------------------------------
-- JOS JAWS - DRAW OTHER FISH
----------------------------------------------------

local function drawOtherFish()

    for i = 1, #otherFish do

        local fish = otherFish[i]

        lcd.drawBitmap(fish.image,fish.x,fish.y)

    end

end

----------------------------------------------------
-- JOS JAWS - LEVEL 2 - CREATE SHARK
----------------------------------------------------

local function spawnShark()

    -- Don't spawn another shark if one already exists
    if shark ~= nil then
        return
    end

    local newShark = {}

    ------------------------------------------------
    -- RANDOMLY CHOOSE SHARK
    ------------------------------------------------

    if math.random(1, 2) == 1 then

        ------------------------------------------------
        -- SHARK WR
        -- LEFT → RIGHT
        ------------------------------------------------

        newShark.image = sharkwr

        newShark.w = sharkWRW
        newShark.h = sharkWRH

        newShark.x = -newShark.w - 5

        newShark.direction = 1

    else

        ------------------------------------------------
        -- SHARK WL RIGHT to LEFT
        ------------------------------------------------

        newShark.image = sharkwl

        newShark.w = sharkWLW
        newShark.h = sharkWLH

        newShark.x = lcdW + 5

        newShark.direction = -1

    end

    ------------------------------------------------
    -- RANDOM HEIGHT BELOW TOP BAR
    ------------------------------------------------

    newShark.y = math.random(40,lcdH - newShark.h - 5)
    newShark.speed = sharkSpeed
    shark = newShark

end

----------------------------------------------------
-- JOS JAWS - LEVEL 2 - UPDATE SHARK
----------------------------------------------------

local function updateShark()

    ------------------------------------------------
    -- NO SHARK CURRENTLY ACTIVE
    ------------------------------------------------

    if shark == nil then
        return
    end

    ------------------------------------------------
    -- MOVE SHARK
    ------------------------------------------------

    shark.x = shark.x + (shark.speed * shark.direction)

    ------------------------------------------------
    -- SHARK MOVED OFF SCREEN
    ------------------------------------------------

    if shark.direction == 1 then

        -- Shark moving LEFT → RIGHT
        if shark.x > lcdW then
            shark = nil
            sharkTimer = sharkSpawnDelay
        end

    else

        -- Shark moving RIGHT to LEFT
        if shark.x + shark.w < 0 then
            shark = nil
            sharkTimer = sharkSpawnDelay
        end

    end

end

----------------------------------------------------
-- JOS JAWS - LEVEL 2 - DRAW SHARK
----------------------------------------------------

local function drawShark()

    -- No shark currently active
    if shark == nil then
        return
    end

    lcd.drawBitmap(shark.image,shark.x,shark.y)

end
----------------------------------------------------
-- JOS JAWS - LEVEL 2 - SHARK TIMER
----------------------------------------------------

local function updateSharkTimer()

    if shark ~= nil then
        return
    end

    if sharkTimer > 0 then
        sharkTimer = sharkTimer - 1
        return
    end

    spawnShark()

end

----------------------------------------------------
-- JOS JAWS - LEVEL 2 - CREATE TREASURE CHEST
----------------------------------------------------

local function spawnChest()

    ------------------------------------------------
    -- EXTRA SAFE SPACE AROUND JOS
    ------------------------------------------------

    local safeX = 30
    local safeY = 30

    local attempts = 0
    local validPosition = false

    ------------------------------------------------
    -- KEEP TRYING UNTIL WE FIND A SAFE POSITION
    ------------------------------------------------

    while not validPosition and attempts < 100 do

        attempts = attempts + 1

        ------------------------------------------------
        -- RANDOM CHEST POSITION
        --
        -- Keep the chest at least 100px from
        -- the right edge of the screen.
        ------------------------------------------------

        chestX = math.random(10,lcdW - chestW - 80)
        chestY = math.random(40,lcdH - chestH - 10)

        ------------------------------------------------
        -- CHECK AGAINST JOS
        ------------------------------------------------

        local safeJosLeft = josX - safeX
        local safeJosRight = josX + josW + safeX

        local safeJosTop = josY - safeY
        local safeJosBottom = josY + josH + safeY

        ------------------------------------------------
        -- CHEST IS SAFE IF IT DOES NOT OVERLAP
        -- JOS OR HIS SAFE AREA
        ------------------------------------------------

        if chestX + chestW < safeJosLeft or
           chestX > safeJosRight or
           chestY + chestH < safeJosTop or
           chestY > safeJosBottom then

            validPosition = true

        end

    end

    ------------------------------------------------
    -- START CHEST VISIBILITY
    ------------------------------------------------

    chestTimer = chestVisibleTime
    chestVisible = true

end

----------------------------------------------------
-- JOS JAWS - LEVEL 2 - UPDATE TREASURE CHEST
----------------------------------------------------

local function updateChest()

    if firstChestTimer > 0 then
        firstChestTimer = firstChestTimer - 1
        return
    end

    if chestVisible then

        chestTimer = chestTimer - 1

        if chestTimer <= 0 then
            chestVisible = false
            chestRespawnTimer = chestRespawnDelay
        end

        return

    end

    if chestRespawnTimer > 0 then
        chestRespawnTimer = chestRespawnTimer - 1
        return
    end

    spawnChest()

end

----------------------------------------------------
-- JOS JAWS - LEVEL 2 - DRAW TREASURE CHEST
----------------------------------------------------

local function drawChest()

    if not chestVisible then
        return
    end

    lcd.drawBitmap(chest,chestX,chestY)

end

----------------------------------------------------
-- JOS JAWS - LEVEL 2 - CHECK CHEST COLLISION
----------------------------------------------------

local function checkChestCollision()

    if not chestVisible then
        return
    end

    if chestX < josX + josW and
       chestX + chestW > josX and
       chestY < josY + josH and
       chestY + chestH > josY then

        chestsCollected = chestsCollected + 1
        chestVisible = false

    end

end

----------------------------------------------------
-- JOS JAWS - CREATE NEW KEY POSITION
----------------------------------------------------

local function spawnKey()

    ------------------------------------------------
    -- EXTRA SAFE SPACE AROUND JOS
    ------------------------------------------------

    local safeX = 20
    local safeY = 20

    local attempts = 0
    local validPosition = false

    ------------------------------------------------
    -- KEEP TRYING UNTIL WE FIND A SAFE POSITION
    ------------------------------------------------

    while not validPosition and attempts < 100 do

        attempts = attempts + 1

        ------------------------------------------------
        -- RANDOM KEY POSITION
        ------------------------------------------------

        keyX = math.random(10,lcdW - keyW - 10)
        keyY = math.random(40,lcdH - keyH - 10)

        local safeJosLeft = josX - safeX
        local safeJosRight = josX + josW + safeX

        local safeJosTop = josY - safeY
        local safeJosBottom = josY + josH + safeY

        ------------------------------------------------
        -- KEY IS SAFE IF IT DOES NOT OVERLAP
        ------------------------------------------------

        if keyX + keyW < safeJosLeft or
           keyX > safeJosRight or
           keyY + keyH < safeJosTop or
           keyY > safeJosBottom then

            validPosition = true

        end

    end

    ------------------------------------------------
    -- START KEY
    ------------------------------------------------

    keyTimer = keyVisibleTime

    keyVisible = true

    keyWaiting = false

    keyFloat = 0

end

----------------------------------------------------
-- JOS JAWS - UPDATE KEY
----------------------------------------------------

local function updateKey()

    if keyFound then
        return
    end


    ------------------------------------------------
    -- KEY CURRENTLY VISIBLE
    ------------------------------------------------

    if keyVisible then

        keyTimer = keyTimer - 1

        -- Gentle floating movement
        keyFloat = keyFloat + 0.15

        ------------------------------------------------
        -- KEY MISSED
        ------------------------------------------------

        if keyTimer <= 0 then

            keyVisible = false

            keyWaiting = true

            -- Count this as a missed key
            keyMisses = keyMisses + 1


            ------------------------------------------------
            -- EVERY 5 MISSES INCREASE DIFFICULTY
            ------------------------------------------------

            if keyMisses % 5 == 0 then

                -- Increase maximum jellyfish by 25%
                maxJellyfish = math.ceil(maxJellyfish * 1.25)

                -- Make them appear more frequently
                jellySpawnRate = math.max(
                    20,
                    math.floor(jellySpawnRate * 0.80)
                )

            end


            -- Hidden timer
            keyTimer = keyHiddenTime

        end


    ------------------------------------------------
    -- KEY CURRENTLY HIDDEN
    ------------------------------------------------

    elseif keyWaiting then

        keyTimer = keyTimer - 1

        if keyTimer <= 0 then

            spawnKey()

        end

    end

end


----------------------------------------------------
-- JOS JAWS - DRAW KEY
----------------------------------------------------

local function drawKey()

    if keyFound then
        return
    end

    if not keyVisible then
        return
    end

    -- Gentle vertical floating
    local drawY = keyY + math.sin(keyFloat) * 3

    lcd.drawBitmap(key, keyX, drawY)

end

----------------------------------------------------
-- JOS JAWS - CHECK JELLYFISH COLLISION
----------------------------------------------------

local function checkJellyfishCollision()

    -- Don't check collisions while Jos is
    -- temporarily invulnerable

    if hitTimer > 0 then
        return
    end

    for i = #jellyfish, 1, -1 do

        local j = jellyfish[i]

        if j.x < josX + josW and
           j.x + j.w > josX and
           j.y < josY + josH and
           j.y + j.h > josY then

            livesCount = livesCount - 1
            hitTimer = hitDuration

            ------------------------------------------------
            -- REMOVE JELLYFISH
            ------------------------------------------------

            table.remove(jellyfish, i)

            playTone(250, 400, 0, PLAY_NOW)

            break

        end

    end

    ------------------------------------------------
    -- GAME OVER
    ------------------------------------------------

    if livesCount <= 0 then

        gameOver = true

    end

end


----------------------------------------------------
-- JOS JAWS - CHECK KEY COLLISION
----------------------------------------------------

local function checkKeyCollision()

    if keyFound then
        return
    end

    if not keyVisible then
        return
    end

    local drawY = keyY + math.sin(keyFloat) * 3

    if keyX < josX + josW and
       keyX + keyW > josX and
       drawY < josY + josH and
       drawY + keyH > josY then

        ------------------------------------------------
        -- JOS FOUND THE KEY
        ------------------------------------------------

        keyFound = true

        keyVisible = false

        levelCompleteTimer = 90

        playTone(800, 500, 0, PLAY_NOW)

    end

end

----------------------------------------------------
-- JOS JAWS - LEVEL 2 - CHECK SHARK COLLISION
----------------------------------------------------

local function checkSharkCollision()

    if shark == nil then
        return
    end

    ------------------------------------------------
    -- JOS COLLISION BOX
    ------------------------------------------------

    local josCollisionX = josX + (josW - josCollisionW) / 2
    local josCollisionY = josY + (josH - josCollisionH) / 2

    ------------------------------------------------
    -- CHECK COLLISION
    ------------------------------------------------

    if shark.x < josCollisionX + josCollisionW and
       shark.x + shark.w > josCollisionX and
       shark.y < josCollisionY + josCollisionH and
       shark.y + shark.h > josCollisionY then

        sharkHit = true
        gameOver = true
        playTone(150, 800, 0, PLAY_NOW)

    end

end

----------------------------------------------------
-- JOS JAWS - DRAW LEVEL COMPLETE
----------------------------------------------------

local function drawLevelComplete()

    lcd.drawFilledRectangle(0,lcdH / 2 - 35,lcdW,70,BLACK)
    lcd.drawText(lcdW / 2,lcdH / 2 - 25,"KEY FOUND!",CENTER + DBLSIZE + YELLOW)
    lcd.drawText(lcdW / 2,lcdH / 2 + 5,"LEVEL 1 COMPLETE",CENTER + MIDSIZE + WHITE)

end

----------------------------------------------------
-- JOS JAWS - DRAW GAME OVER
----------------------------------------------------

local function drawGameOver()

    if not gameoverVisible then
        return
    end

    lcd.drawFilledRectangle(0,lcdH / 2 - 35,lcdW,70,BLACK)
    lcd.drawText(lcdW / 2,lcdH / 2 - 20,"GAME OVER",CENTER + DBLSIZE + RED)
    lcd.drawText(lcdW / 2,lcdH / 2 + 10,"PRESS ENTER",CENTER + MIDSIZE + WHITE)

end

----------------------------------------------------
-- GAMEOVER FLASH
----------------------------------------------------

local function gameoverFlash()

    if not gameOver then
        return
    end

    gameoverTimer = gameoverTimer + 1

    if gameoverTimer % 20 < 10 then

        gameoverVisible = true

    else

        gameoverVisible = false

    end

end

----------------------------------------------------
-- JOS JAWS - RESET GAME
----------------------------------------------------

local function resetGame()

    scoreSubmitted = false

    jellyfish = {}
    clownfish = {}
    otherFish = {}

    jellyTimer = 0
    clownTimer = 0
    otherFishTimer = 0

    livesCount = 3
    keyFound = false

    -- RESET KEY
    keyVisible = false
    keyWaiting = true
    keyTimer = keyHiddenTime
    keyMisses = 0
    keyFloat = 0

    -- REST AIR TIME & SCUBA
    airTime = maxAirTime
    scubaVisible = false
    scubaX = -scubaW
    scubaTriggered = false

    -- RESET LEVEL 2 CHEST SYSTEM
    chestVisible = false
    chestTimer = 0
    chestRespawnTimer = 0
    firstChestTimer = 0
    chestsCollected = 0

    -- RESET JELLYFISH DIFFICULTY
    maxJellyfish = 6
    jellySpawnRate = 65

    gameOver = false

    hitTimer = 0

    gameoverTimer = 0
    gameoverVisible = true

    levelCompleteTimer = 0

    level = 1

    -- JOS START POSITION
    josX = 100
    josY = lcdH / 2

    gameState = "game"

end

----------------------------------------------------
-- JOS JAWS - INTRO SCREEN
----------------------------------------------------

local function drawJawsIntro()

    lcd.clear()

    if josjawsintro then
        lcd.drawBitmap(josjawsintro, 0, 0)
    end

end

----------------------------------------------------
-- JOS JAWS - UPDATE INTRO
----------------------------------------------------

local function updateJawsIntro()

    if jawsIntroTime == 0 then
      jawsIntroTime = getTime()
    end

    ------------------------------------------------
    -- PLAY INTRO SOUND ONCE
    ------------------------------------------------

    if not jawsIntroPlayed then

        playFile(josjawsintroSound)

        jawsIntroPlayed = true

    end

    ------------------------------------------------
    -- CHECK 12 SECOND TIMER
    ------------------------------------------------

    if getTime() - jawsIntroTime >= jawsIntroDuration then

        gameState = "game"

    end

end

---**************************************************************************************************---
-- JOS JAWS - GAME CODE END
---**************************************************************************************************---

----------------------------------------------------
-- MAIN LOOP
----------------------------------------------------

local function run(event)

    ------------------------------------------------
    -- LEADERBOARD
    ------------------------------------------------

    if leaderboardActive then

        local scoreAction = JJScores.run(event)

        if scoreAction == "start" then

            leaderboardActive = false

            gameState = "jawsIntro"
            jawsIntroTime = 0
            jawsIntroPlayed = false

        elseif scoreAction == "exit" then

            return "/SCRIPTS/TOOLS/Jos Games/Selector.lua"

        end

        return 0

    end

    lcd.clear()

----------------------------------------------------
-- JOS JAWS - GAME STATE
----------------------------------------------------

if gameState == "jawsIntro" then
    
    updateJawsIntro()
    drawJawsIntro()

    return 0

end
------------------------------------------------
-- GAME OVER
------------------------------------------------

if gameOver then

    drawBackground()

    drawJellyfish()
    drawClownfish()
    drawOtherFish()

    if level == 2 then
        drawShark()
    end

    if level == 1 then
        drawKey()
    end

    drawJos()
    drawTopBar()

    drawGameOver()

    gameoverFlash()


    if event == EVT_ENTER_BREAK and not scoreSubmitted then

      scoreSubmitted = true
      JJScores.submitScore(chestsCollected)
      leaderboardActive = true
      return 0

    end

    return 0

end

------------------------------------------------
-- LEVEL COMPLETE
------------------------------------------------

if keyFound and level == 1 then

    drawBackground()

    drawClownfish()
    drawOtherFish()
    drawJellyfish()
    drawJos()

    drawTopBar()

    drawLevelComplete()

    if event == EVT_ENTER_BREAK then

        level = 2

        level2Started = true

        shark = nil
        sharkTimer = 60

        chestsCollected = 0
        chestVisible = false
        chestTimer = 0
        chestRespawnTimer = 0
        firstChestTimer = firstChestDelay

        jellyfish = {}
        jellyTimer = 0
        maxJellyfish = 9
        jellySpawnRate = 40

        otherFish = {}
        otherFishTimer = 0

        clownfish = {}
        clownTimer = 0

        keyFound = true

    end

    return 0

end

------------------------------------------------
-- NORMAL GAME
------------------------------------------------

updateJos()
updateJellyfish()
updateClownfish()
updateOtherFish()
updateAir()
updateScuba()
checkScubaCollision()

if level == 1 then
    updateKey()
    checkKeyCollision()
end


if level == 2 then
    updateSharkTimer()
    updateShark()
    checkSharkCollision()

    updateChest()
    checkChestCollision()
end

checkJellyfishCollision()

------------------------------------------------
-- DRAW
------------------------------------------------

drawBackground()
drawClownfish()
drawOtherFish()
drawJellyfish()
drawScuba()

if level == 1 then
    drawKey()
end

if level == 2 then
    drawShark()
    drawChest()
end

drawJos()
drawTopBar()
drawAirBar()

------------------------------------------------
-- GAME OVER FLASH
------------------------------------------------

gameoverFlash()
return 0

end

----------------------------------------------------
-- RETURN
----------------------------------------------------

return { run = run }
