-- TNS|Jos Jaws Scores|TNE -- 

----------------------------------------------------
-- JOS JAWS - TOP 5 SCORES
----------------------------------------------------

local scorePath = "/SCRIPTS/TOOLS/Jos Games/Jos Jaws/JJScoreFile.txt"
local scoreBackground = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/scorec.png")
local conBackground = bitmap.open("/SCRIPTS/TOOLS/Jos Games/Jos Jaws/conbg.png")

local MAX_SCORES = 5
local MAX_NAME_LENGTH = 12

----------------------------------------------------
-- VARIABLES
----------------------------------------------------

local scores = {}

local screen = "leaderboard"

local playerScore = 0
local playerName = {}
local nameCursor = 1

local message = ""

local afterScore = false

local characters = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

----------------------------------------------------
-- LOAD SCORES
----------------------------------------------------

local function loadScores()

    scores = {}

    local f = io.open(scorePath, "r")

    if not f then

        -- Create an empty score file

        local newFile = io.open(scorePath, "w")

        if newFile then
            io.close(newFile)
        end

        return
    end

    local data = io.read(f, 4096)

    io.close(f)

    if not data then
        return
    end

    ------------------------------------------------
    -- READ NAME,SCORE
    ------------------------------------------------

    for line in string.gmatch(data, "([^\n]+)") do

        line = string.gsub(line, "\r", "")

        local name, score =
            string.match(line, "^(.-),(%d+)$")

        if name and score then

            scores[#scores + 1] = {
                name = name,
                score = tonumber(score)
            }

        end
    end

    ------------------------------------------------
    -- SORT HIGHEST FIRST
    ------------------------------------------------

    table.sort(scores, function(a, b)
        return a.score > b.score
    end)

    ------------------------------------------------
    -- KEEP ONLY TOP 5
    ------------------------------------------------

    while #scores > MAX_SCORES do
        table.remove(scores)
    end

end

----------------------------------------------------
-- SAVE SCORES
----------------------------------------------------

local function saveScores()

    local f = io.open(scorePath, "w")

    if not f then
        message = "Save Failed"
        return false
    end

    for i = 1, #scores do

        io.write(
            f,
            scores[i].name .. "," ..
            scores[i].score .. "\n"
        )

    end

    io.close(f)

    message = "Scores Saved"

    return true

end

----------------------------------------------------
-- CHECK SCORE
----------------------------------------------------

local function qualifies(score)

    if #scores < MAX_SCORES then
        return true
    end

    return score > scores[MAX_SCORES].score

end

----------------------------------------------------
-- START NAME ENTRY
----------------------------------------------------

local function startNameEntry(score)

    playerScore = score

    playerName = {}

    for i = 1, MAX_NAME_LENGTH do
        playerName[i] = " "
    end

    nameCursor = 1

    screen = "nameEntry"

end

----------------------------------------------------
-- SAVE NEW SCORE
----------------------------------------------------

local function saveNewScore()

    local name = ""

    for i = 1, MAX_NAME_LENGTH do
        name = name .. playerName[i]
    end

    name = string.gsub(name, "%s+$", "")

    if name == "" then
        name = "PLAYER"
    end

    ----------------------------------------------------
    -- CHECK IF PLAYER ALREADY EXISTS
    ----------------------------------------------------

    local existingPlayer = nil

    for i = 1, #scores do

      if string.upper(scores[i].name) == string.upper(name) then

        existingPlayer = i
        break

      end

    end

    ----------------------------------------------------
    -- ADD OR UPDATE PLAYER SCORE
    ----------------------------------------------------

    if existingPlayer then

      if playerScore > scores[existingPlayer].score then

        scores[existingPlayer].score = playerScore

      end

    else

      -- New player

      table.insert(scores, {
        name = name,
        score = playerScore
      })

    end

    ------------------------------------------------
    -- SORT HIGHEST FIRST
    ------------------------------------------------

    table.sort(scores, function(a, b)
        return a.score > b.score
    end)

    ------------------------------------------------
    -- REMOVE SCORES BELOW TOP 5
    ------------------------------------------------

    while #scores > MAX_SCORES do
        table.remove(scores)
    end

    if saveScores() then
        screen = "leaderboard"
    end

end

----------------------------------------------------
-- CHANGE CHARACTER
----------------------------------------------------

local function nextChar(current, direction)

    local index =
        string.find(characters, current, 1, true) or 1

    index = index + direction

    if index > #characters then
        index = 1
    elseif index < 1 then
        index = #characters
    end

    return string.sub(characters, index, index)

end

----------------------------------------------------
-- DRAW LEADERBOARD
----------------------------------------------------

local function drawLeaderboard()

    lcd.clear()

    if scoreBackground then
        lcd.drawBitmap(scoreBackground, 0, 0)
    end

    ------------------------------------------------
    -- SCORE LIST
    ------------------------------------------------

    for i = 1, MAX_SCORES do

        local y = 90 + ((i - 1) * 24)

        if scores[i] then

            lcd.drawText(
                100,
                y,
                tostring(i) .. ". " .. scores[i].name,
                BLACK
            )

            lcd.drawText(
                LCD_W - 100,
                y,
                tostring(scores[i].score),
                RIGHT + BLACK
            )

        else

            lcd.drawText(
                100,
                y,
                tostring(i) .. ". ---",
                BLACK
            )

            lcd.drawText(
                LCD_W - 100,
                y,
                "---",
                RIGHT + BLACK
            )

        end

    end

    -- DISPLAY MESSAGE IF REQUIRED
    if message ~= "" then
        lcd.drawText(10, LCD_H - 15, message, SMLSIZE + BLACK)
    end

end

----------------------------------------------------
-- DRAW NAME ENTRY
----------------------------------------------------

local function drawNameEntry()

    lcd.clear()

    if conBackground then
        lcd.drawBitmap(conBackground, 0, 0)
    end

    lcd.drawText(LCD_W / 2,158,"SCORE: " .. playerScore,CENTER + BLACK)

    ------------------------------------------------
    -- DISPLAY NAME CHARACTERS
    ------------------------------------------------

    local startX = 140
    local spacing = 16

    for i = 1, MAX_NAME_LENGTH do

        local flags = BLACK

        if i == nameCursor then
            flags = flags + INVERS
        end

        lcd.drawText(
            startX + ((i - 1) * spacing),
            185,
            playerName[i],
            flags
        )

    end

end

----------------------------------------------------
-- UPDATE LEADERBOARD
----------------------------------------------------

local function updateLeaderboard(event)

    if event == EVT_ENTER_BREAK then

        if afterScore then
            screen = "finished"
        else
            screen = "gameStart"
        end

    end

end

----------------------------------------------------
-- UPDATE NAME ENTRY
----------------------------------------------------

local function updateNameEntry(event)

    ------------------------------------------------
    -- ROLLER RIGHT
    ------------------------------------------------

    if event == EVT_ROT_RIGHT then

        playerName[nameCursor] =
            nextChar(playerName[nameCursor], 1)

    ------------------------------------------------
    -- ROLLER LEFT
    ------------------------------------------------

    elseif event == EVT_ROT_LEFT then

        playerName[nameCursor] =
            nextChar(playerName[nameCursor], -1)

    ------------------------------------------------
    -- ENTER
    ------------------------------------------------

    elseif event == EVT_ENTER_BREAK then

        if nameCursor < MAX_NAME_LENGTH then

            nameCursor = nameCursor + 1

        else

            saveNewScore()

        end

    end

end

----------------------------------------------------
-- START LEADERBOARD
----------------------------------------------------

local function start()

    loadScores()

    screen = "leaderboard"

    message = ""
    afterScore = false

end

----------------------------------------------------
-- SUBMIT SCORE
----------------------------------------------------

local function submitScore(score)

    afterScore = true
    playerScore = tonumber(score) or 0

    loadScores()

    if qualifies(playerScore) then

        startNameEntry(playerScore)

    else

        screen = "leaderboard"
        message = "Score did not qualify"

    end

end

----------------------------------------------------
-- MAIN RUN FUNCTION
----------------------------------------------------
local function run(event)

    ------------------------------------------------
    -- LEADERBOARD
    ------------------------------------------------

    if screen == "leaderboard" then

        updateLeaderboard(event)
        drawLeaderboard()

        if screen == "finished" then
            return "exit"
        elseif screen == "gameStart" then
            return "start"
        end

    ------------------------------------------------
    -- NAME ENTRY
    ------------------------------------------------

    elseif screen == "nameEntry" then

        updateNameEntry(event)
        drawNameEntry()

    end

    return 0

end

----------------------------------------------------
-- RETURN FUNCTIONS
----------------------------------------------------

return {
    run = run,
    start = start,
    submitScore = submitScore
}
